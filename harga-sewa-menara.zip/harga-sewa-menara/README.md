# Model Penentuan Harga Sewa Gedung Menara

Perangkat analisis untuk menetapkan tarif sewa gedung perkantoran bertingkat, dengan harga yang **berbeda per lantai dan per unit** berdasarkan faktor yang dapat dijelaskan dan diaudit.

Ditujukan bagi pembaca tanpa latar belakang penilaian properti. Seluruh rumus disertai penjelasan bahasa sederhana, contoh angka, dan sumber rujukan.

---

## Isi Paket

| Berkas | Keterangan |
|---|---|
| `docs/HANDBOOK-HARGA-SEWA-MENARA.md` | Handbook lengkap, 22 bab, 40+ rumus bersumber. |
| `docs/HANDBOOK-HARGA-SEWA-MENARA.pdf` | Versi PDF siap cetak, 43 halaman. |
| `data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx` | Model Excel dengan 12 lembar, 2.674 rumus hidup, 64 unit contoh. |
| `config/parameters.yaml` | Sumber tunggal seluruh parameter model. |
| `scripts/build_workbook.py` | Membangun ulang berkas Excel dari konfigurasi. |
| `scripts/validate_data.py` | Memeriksa mutu data unit sebelum masuk model. |
| `scripts/build_pdf.py` | Mengubah handbook menjadi PDF. |
| `CLAUDE.md` | Instruksi kerja untuk Claude Code. |

---

## Mulai dalam 5 Menit

1. Buka `data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx`.
2. Baca lembar **`00_BACA_SAYA`** — berisi legenda warna dan urutan pengisian.
3. Buka lembar **`09_RINGKASAN`** untuk melihat hasil akhir dan sembilan pemeriksaan mutu.
4. Ubah satu angka di **`01_ASUMSI`** (misalnya tarif service charge) dan amati seluruh model menyesuaikan.
5. Baca handbook Bab 19 untuk prosedur kerja 10 langkah dari data mentah ke daftar harga.

---

## Cara Kerja Model

```
        Data pembanding pasar                Data keuangan gedung
                 │                                    │
                 ▼                                    ▼
        Grid penyesuaian (Bab 5)          Tarif dibutuhkan & titik impas (Bab 6)
                 │                                    │
                 └────────────► Pagar pengaman (Bab 7) ◄────────┘
                                        │
                                        ▼
                        TARIF DASAR GEDUNG  R*
                                        │
                                        ▼
          R* × F_lantai × F_view × F_posisi × F_ukuran × F_kondisi × F_denah
                                        │
                                        ▼
                        Kalibrasi ke rata-rata pasar (Bab 11)
                                        │
                                        ▼
                        TARIF PER UNIT  →  Daftar harga
```

Model bersifat **multiplikatif**: mengubah tarif dasar otomatis menyesuaikan seluruh unit secara proporsional, tanpa perhitungan ulang manual.

---

## Perintah

```bash
# Pasang kebutuhan (umumnya sudah tersedia)
pip install openpyxl pandas pyyaml

# Bangun ulang berkas Excel dari config/parameters.yaml
python3 scripts/build_workbook.py

# Periksa mutu data sebelum perhitungan
python3 scripts/validate_data.py --xlsx data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx
python3 scripts/validate_data.py data/template/master_unit.csv

# Bangun PDF handbook
python3 scripts/build_pdf.py
```

---

## Prinsip Rancangan

Model ini dirancang agar tetap murah dirawat dalam jangka panjang. Sepuluh keputusan rancangan beserta alasannya dijelaskan pada **Bab 20** handbook. Ringkasnya:

- Parameter, data, dan rumus disimpan terpisah — pembaruan kuartalan hanya menyentuh satu lembar.
- Model multiplikatif, sehingga tidak perlu menghitung ulang setiap unit saat tarif dasar berubah.
- Kalibrasi otomatis menjaga rata-rata tertimbang selalu sama dengan jangkar pasar.
- Format terbuka seluruhnya: Markdown, YAML, XLSX, CSV, PDF. Tidak ada penguncian vendor.
- Berkas Excel dapat dibangun ulang dari nol dalam satu menit bila rusak.
- Sembilan pemeriksaan mutu tertanam di dalam berkas dan berjalan otomatis.
- Struktur sudah siap untuk banyak gedung sejak awal.

---

## Peringatan Penting

**Seluruh angka dalam berkas Excel adalah data karangan.** Angka disusun agar menyerupai kondisi pasar perkantoran Jakarta pertengahan 2026 berdasarkan laporan publik Colliers, Cushman & Wakefield, CBRE, JLL, dan Bank Indonesia, tetapi tidak mewakili gedung nyata mana pun.

**Besaran faktor pengali wajib dikalibrasi** dengan data setempat sebelum dipakai untuk keputusan nyata. Prosedurnya ada pada Bab 9.4 dan Bab 12.

**Model ini bukan laporan penilaian.** Untuk keperluan yang mengikat secara hukum — jaminan utang, pelaporan keuangan, transaksi, atau sengketa — hasilnya wajib diverifikasi oleh Penilai Publik berizin yang tunduk pada Standar Penilaian Indonesia.

**Ketentuan perpajakan dapat berubah.** Tarif PPh Final dan PPN yang tercantum harus diverifikasi ke sumber resmi pada saat digunakan.

---

## Rujukan Utama

Standar pengukuran mengikuti ANSI/BOMA Z65.1. Kerangka penilaian mengikuti IVS 105 dan SPI 106 (KEPI & SPI Edisi VII 2018, MAPPI). Besaran premi lantai berlandaskan penelitian Nutt (2016, MIT), Nase dkk. (2019), Koster dkk. (2014), dan Chau dkk. (2012). Daftar lengkap beserta tautan ada pada Bab 22 handbook dan lembar `11_SUMBER` berkas Excel.
