# Instruksi untuk Claude Code

Repositori ini berisi model penetapan harga sewa gedung perkantoran bertingkat beserta handbook penjelasnya. Bacalah berkas ini lebih dulu sebelum mengerjakan tugas apa pun di sini.

---

## Peta Repositori

```
config/parameters.yaml    Sumber tunggal seluruh parameter. Ubah di sini, bukan di Excel.
data/dummy/*.xlsx         Model Excel hasil bangun. Jangan diedit tangan; bangun ulang.
data/template/            Tempat data nyata pengguna diletakkan.
docs/*.md                 Handbook. Sumber kebenaran untuk seluruh rumus.
scripts/build_workbook.py Membangun Excel dari parameters.yaml.
scripts/validate_data.py  Memeriksa mutu data unit.
scripts/build_pdf.py      Membangun PDF dari handbook.
assets/style/             Template LaTeX dan CSS untuk PDF.
```

---

## Aturan Wajib

1. **Jangan pernah mengganti rumus di lembar `04_KALKULASI` dengan angka tetap.** Lembar itu adalah mesin perhitungan. Rumus yang diganti angka akan merusak model secara diam-diam.

2. **Seluruh perubahan parameter dilakukan di `config/parameters.yaml`, lalu jalankan `build_workbook.py`.** Jangan mengedit sel Excel secara langsung untuk perubahan yang bersifat permanen.

3. **Setelah setiap pembangunan ulang berkas Excel, wajib menjalankan pemeriksaan rumus:**
   ```bash
   python3 scripts/build_workbook.py
   python3 /mnt/skills/public/xlsx/scripts/recalc.py data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx
   ```
   Berkas tidak boleh diserahkan bila hasilnya `errors_found`.

4. **Recalc yang bersih hanya membuktikan rumus dapat dihitung, bukan bahwa angkanya benar.** Setelah recalc, baca beberapa nilai kunci dengan `load_workbook(data_only=True)` dan bandingkan dengan perhitungan manual: faktor kalibrasi `04_KALKULASI!E7`, rata-rata tertimbang `09_RINGKASAN!B8`, dan status sembilan pemeriksaan mutu.

5. **Setiap perubahan asumsi dicatat di `CHANGELOG.md`** beserta alasannya dan tanggalnya.

6. **Jangan menghapus data dummy.** Bila akan diganti dengan data nyata, salin ke berkas baru di `data/template/`.

7. **Angka apa pun yang berasal dari luar wajib disertai sumber** — dicatat di lembar `11_SUMBER` pada Excel dan di Bab 22 handbook. Jangan memasukkan angka tanpa asal-usul.

8. **Handbook dan model harus tetap sinkron.** Bila sebuah rumus atau angka contoh diubah di salah satunya, ubah juga di yang lain. Contoh angka pada Bab 6 dan Bab 7 handbook harus sama dengan keluaran berkas Excel.

9. **Jangan menambah faktor pengali baru tanpa dasar.** Setiap faktor harus dapat diamati objektif, diverifikasi pihak ketiga, dan tidak tumpang tindih dengan faktor yang sudah ada. Batasi pada 5–7 faktor (Bab 8.3).

10. **Jangan mengubah status kalibrasi menjadi `TERKALIBRASI`** kecuali regresi Bab 12 benar-benar sudah dijalankan dan memenuhi syarat minimum: 30 kontrak di 8 lantai berbeda, R-kuadrat terkoreksi minimal 0,50, dan nilai-p tiap koefisien maksimal 0,10.

---

## Alur Kerja Baku

### Mengubah parameter
```bash
# 1. Sunting config/parameters.yaml
# 2. Bangun ulang
python3 scripts/build_workbook.py
# 3. Verifikasi
python3 /mnt/skills/public/xlsx/scripts/recalc.py data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx
# 4. Catat di CHANGELOG.md
```

### Memasukkan data unit nyata
```bash
# 1. Letakkan CSV di data/template/master_unit.csv
# 2. Periksa mutunya lebih dulu
python3 scripts/validate_data.py data/template/master_unit.csv
# 3. Perbaiki seluruh GALAT sebelum melanjutkan
# 4. Sesuaikan config/parameters.yaml (NLA, jumlah lantai) agar cocok
# 5. Bangun ulang dan verifikasi
```

### Memperbarui handbook
```bash
# 1. Sunting docs/HANDBOOK-HARGA-SEWA-MENARA.md
# 2. Bangun ulang PDF
python3 scripts/build_pdf.py
# 3. Periksa halaman yang berubah dengan pdftoppm
```

---

## Rujukan Rumus

Seluruh rumus bernomor dan didefinisikan di handbook. Saat mengerjakan tugas, sebutkan nomor rumusnya agar mudah ditelusuri.

| Kebutuhan | Rumus | Bab |
|---|---|---|
| Faktor beban dan luas | 3.1–3.3 | 3 |
| Grid penyesuaian pembanding | 5.1–5.3 | 5 |
| Tarif dibutuhkan dan titik impas | 6.1–6.7 | 6 |
| Pagar pengaman harga | 7.1–7.3 | 7 |
| Tarif per unit | 8.1–8.3 | 8 |
| Faktor lantai | 9.1–9.2 | 9 |
| Faktor non-lantai | 10.1–10.6 | 10 |
| Kalibrasi | 11.1–11.3 | 11 |
| Regresi hedonik | 12.1–12.2 | 12 |
| Pajak dan tagihan | 13.1–13.7 | 13 |
| Sewa efektif bersih | 14.1–14.4 | 14 |
| Eskalasi dan nilai kini | 15.1–15.3 | 15 |
| Sensitivitas dan elastisitas | 16.1–16.5 | 16 |
| Uji mutu | 17.1–17.3 | 17 |

Ringkasan seluruh rumus ada pada Lampiran A handbook.

---

## Batasan Fungsi Excel

Berkas dihasilkan dengan `openpyxl` dan diverifikasi dengan LibreOffice. Karena itu:

- **Gunakan** `SUMIFS`, `COUNTIFS`, `AVERAGEIFS`, `INDEX`, `MATCH`, `IFERROR`, `SUMPRODUCT`, `MEDIAN`, `STDEV`, `ROUND`.
- **Jangan gunakan** `XLOOKUP`, `XMATCH`, `SORT`, `FILTER`, `UNIQUE`, `SEQUENCE` — tidak dapat dievaluasi dan akan menghasilkan berkas rusak tanpa peringatan.
- Nama lembar diawali angka, sehingga **wajib diapit tanda kutip** dalam rumus lintas lembar: `='01_ASUMSI'!$B$20`.

---

## Yang Tidak Boleh Dilakukan

- Menyajikan hasil model sebagai laporan penilaian resmi.
- Menaikkan atau menurunkan faktor pengali agar hasilnya "terlihat bagus".
- Memaksa koefisien regresi menjadi positif ketika data menunjukkan sebaliknya. Koefisien negatif adalah informasi, bukan kesalahan.
- Menyalin besaran premi dari penelitian luar negeri langsung ke pasar setempat tanpa kalibrasi.
- Mengabaikan pemeriksaan mutu yang berstatus `PERIKSA` dengan alasan waktu.
