#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_workbook.py
Membangun berkas Excel model penetapan harga sewa gedung menara.

Seluruh parameter dibaca dari config/parameters.yaml.
Berkas Excel yang dihasilkan berisi RUMUS, bukan nilai hasil hitung Python,
sehingga tetap hidup ketika penggunanya mengubah asumsi.

Pemakaian:
    python3 scripts/build_workbook.py
    python3 scripts/build_workbook.py --out data/dummy/Model.xlsx
"""

import argparse
import random
from pathlib import Path

import yaml
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# ----------------------------------------------------------------------------
# Konstanta gaya
# ----------------------------------------------------------------------------
FONT = "Arial"

C_INPUT = "0000FF"       # biru: masukan pengguna
C_FORMULA = "000000"     # hitam: rumus lembar sama
C_LINK = "008000"        # hijau: rumus lintas lembar
F_KUNCI = "FFFF00"       # kuning: asumsi kunci
F_JUDUL = "1F3864"
F_SUBJUDUL = "D9E2F3"
F_HEADER = "2E5C8A"
F_WARN = "FFC7CE"
F_OK = "C6EFCE"

RP = '#,##0;(#,##0);-'
RP2 = '#,##0.0;(#,##0.0);-'
PCT1 = '0.0%'
PCT2 = '0.00%'
FAK = '0.0000'
NUM = '#,##0.0;(#,##0.0);-'

THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def judul(ws, cell, teks, span=8):
    ws[cell] = teks
    ws[cell].font = Font(name=FONT, size=14, bold=True, color="FFFFFF")
    ws[cell].fill = PatternFill("solid", fgColor=F_JUDUL)
    r = ws[cell].row
    c = ws[cell].column
    for i in range(span):
        cc = ws.cell(row=r, column=c + i)
        cc.fill = PatternFill("solid", fgColor=F_JUDUL)
    ws.row_dimensions[r].height = 24


def subjudul(ws, cell, teks, span=8):
    ws[cell] = teks
    ws[cell].font = Font(name=FONT, size=11, bold=True, color="1F3864")
    r = ws[cell].row
    c = ws[cell].column
    for i in range(span):
        ws.cell(row=r, column=c + i).fill = PatternFill("solid", fgColor=F_SUBJUDUL)


def header_baris(ws, row, kolom_teks, col_start=1):
    for i, t in enumerate(kolom_teks):
        c = ws.cell(row=row, column=col_start + i, value=t)
        c.font = Font(name=FONT, size=9, bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=F_HEADER)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = BORDER
    ws.row_dimensions[row].height = 32


def label(ws, row, teks, col=1, bold=False):
    c = ws.cell(row=row, column=col, value=teks)
    c.font = Font(name=FONT, size=10, bold=bold)
    return c


def isi(ws, row, col, nilai, jenis="input", fmt=None, kunci=False, catatan=None,
        cat_col=None):
    """jenis: input | formula | link"""
    c = ws.cell(row=row, column=col, value=nilai)
    warna = {"input": C_INPUT, "formula": C_FORMULA, "link": C_LINK}[jenis]
    c.font = Font(name=FONT, size=10, color=warna,
                  bold=(jenis == "input" and kunci))
    if fmt:
        c.number_format = fmt
    if kunci:
        c.fill = PatternFill("solid", fgColor=F_KUNCI)
    c.border = BORDER
    if catatan is not None:
        cc = ws.cell(row=row, column=cat_col or (col + 2), value=catatan)
        cc.font = Font(name=FONT, size=8, italic=True, color="595959")
    return c


def lebar(ws, spec):
    for kol, w in spec.items():
        ws.column_dimensions[kol].width = w


def normalkan_font(ws):
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None and c.font.name != FONT:
                c.font = Font(name=FONT, size=c.font.size or 10,
                              bold=c.font.bold, italic=c.font.italic,
                              color=c.font.color)


# ============================================================================
# PETA SEL LEMBAR 01_ASUMSI  (label -> alamat)
# ============================================================================
A = {}


def bangun_asumsi(wb, p):
    ws = wb.create_sheet("01_ASUMSI")
    lebar(ws, {"A": 42, "B": 20, "C": 16, "D": 62})
    judul(ws, "A1", "01 — ASUMSI DAN PARAMETER MODEL", span=4)
    ws["A2"] = ("Hanya lembar ini yang diubah rutin. Sel BIRU = masukan Anda. "
                "Sel KUNING = asumsi kunci yang wajib ditinjau tiap kuartal.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True)

    g = p["gedung"]
    t = p["tarif"]
    pg = p["pagar_pengaman"]
    fl = p["faktor_lantai"]
    fu = p["faktor_ukuran"]
    k = p["keuangan"]
    pj = p["pajak"]
    ins = p["insentif"]
    fk = p["faktor_kondisi"]
    am = p["ambang_mutu"]

    r = 4
    subjudul(ws, f"A{r}", "A. IDENTITAS GEDUNG", span=4); r += 1
    baris_id = [
        ("Kode gedung", g["kode"], None, "Dipakai bila model diperluas ke banyak gedung"),
        ("Nama gedung", g["nama"], None, None),
        ("Lokasi", g["lokasi"], None, None),
        ("Grade", g["grade"], None, None),
        ("Jumlah lantai", g["jumlah_lantai"], NUM, None),
        ("Lantai sewa dimulai dari", g["lantai_sewa_mulai"], NUM, None),
        ("GFA — luas kotor lantai (m2)", g["gfa_m2"], RP, None),
        ("NLA — luas disewakan (m2)", g["nla_m2"], RP, "Dasar seluruh perhitungan tarif"),
        ("Standar pengukuran", g["standar_pengukuran"], None,
         "Sumber: BOMA — boma.org/boma-standards"),
        ("Faktor beban (load factor)", g["faktor_beban"], PCT1, "Rumus 3.1"),
    ]
    for nama, val, fmt, cat in baris_id:
        label(ws, r, nama)
        isi(ws, r, 2, val, "input", fmt, catatan=cat, cat_col=4)
        A[nama] = f"$B${r}"
        r += 1
    label(ws, r, "Rasio efisiensi gedung (NLA/GFA)")
    isi(ws, r, 2, f"=IFERROR({A['NLA — luas disewakan (m2)']}/{A['GFA — luas kotor lantai (m2)']},0)",
        "formula", PCT1, catatan="Rumus 3.3 — sehat pada 60%–75%", cat_col=4)
    A["nla"] = A["NLA — luas disewakan (m2)"]
    r += 2

    subjudul(ws, f"A{r}", "B. TARIF DASAR GEDUNG", span=4); r += 1
    label(ws, r, "Mode penetapan tarif dasar")
    isi(ws, r, 2, "OTOMATIS", "input", None, kunci=True,
        catatan="OTOMATIS = ikut hasil model di 06. MANUAL = pakai angka di bawah.", cat_col=4)
    A["mode_tarif"] = f"$B${r}"; r += 1
    label(ws, r, "Tarif dasar manual (Rp/m2/bln)")
    isi(ws, r, 2, t["dasar_gedung_rp_m2_bulan"], "input", RP,
        catatan="Hanya dipakai bila mode = MANUAL", cat_col=4)
    A["tarif_manual"] = f"$B${r}"; r += 1
    label(ws, r, "Tarif dasar hasil model (Rp/m2/bln)")
    isi(ws, r, 2, "='06_UJI_KELAYAKAN'!$C$22", "link", RP,
        catatan="Rumus 7.3 — median dari batas bawah, pasar, batas atas", cat_col=4)
    A["tarif_model"] = f"$B${r}"; r += 1
    label(ws, r, "TARIF DASAR DIPAKAI  (R*)", bold=True)
    isi(ws, r, 2, f'=IF({A["mode_tarif"]}="OTOMATIS",{A["tarif_model"]},{A["tarif_manual"]})',
        "formula", RP, kunci=True, catatan="Angka jangkar seluruh model", cat_col=4)
    A["R_bintang"] = f"$B${r}"; r += 1
    label(ws, r, "Service charge (Rp/m2/bln)")
    isi(ws, r, 2, t["service_charge_rp_m2_bulan"], "input", RP, kunci=True,
        catatan="Acuan pasar desentralisasi Jakarta ~Rp62.000 (Colliers Q2 2026)", cat_col=4)
    A["sc"] = f"$B${r}"; r += 1
    label(ws, r, "Satuan pembulatan tarif (Rp)")
    isi(ws, r, 2, t["satuan_pembulatan_rp"], "input", RP, catatan="Rumus 11.3", cat_col=4)
    A["mu"] = f"$B${r}"; r += 1
    label(ws, r, "Basis kalibrasi")
    isi(ws, r, 2, t["basis_kalibrasi"], "input", None,
        catatan="SELURUH_NLA atau UNIT_TERISI — lihat Bab 11.3", cat_col=4)
    A["basis_kalibrasi"] = f"$B${r}"; r += 2

    subjudul(ws, f"A{r}", "C. PAGAR PENGAMAN HARGA", span=4); r += 1
    for nama, key, fmt, cat in [
        ("phi — toleransi terhadap titik impas", "phi_toleransi_impas", PCT1, "Rumus 7.1"),
        ("delta — diskon maksimum thd pasar", "delta_diskon_maks_pasar", PCT1, "Rumus 7.1"),
        ("gamma — premi maksimum thd premium", "gamma_premi_maks", PCT1, "Rumus 7.2"),
        ("Tarif pembanding premium (Rp/m2/bln)", "tarif_premium_pasar_rp", RP,
         "Acuan Grade A CBD ~Rp234.000 (Colliers Q2 2026)"),
        ("Batas bawah faktor total", "faktor_total_min", FAK, "Rumus 8.3"),
        ("Batas atas faktor total", "faktor_total_maks", FAK, "Rumus 8.3"),
    ]:
        label(ws, r, nama)
        isi(ws, r, 2, pg[key], "input", fmt, catatan=cat, cat_col=4)
        A[key] = f"$B${r}"; r += 1
    r += 1

    subjudul(ws, f"A{r}", "D. FAKTOR LANTAI", span=4); r += 1
    label(ws, r, "Model faktor lantai yang aktif")
    isi(ws, r, 2, fl["model_aktif"], "input", None, kunci=True,
        catatan="ZONA (Rumus 9.1) atau LOGARITMIK (Rumus 9.2)", cat_col=4)
    A["model_lantai"] = f"$B${r}"; r += 1
    for nama, val, fmt, cat in [
        ("theta — kekuatan premi vertikal", fl["logaritmik"]["theta"], FAK,
         "Wajib dikalibrasi. Lazim 0,04–0,12"),
        ("Lantai referensi", fl["logaritmik"]["lantai_referensi"], NUM, "Faktor = 1,0000 di lantai ini"),
        ("lambda — parameter pelandaian", fl["logaritmik"]["lambda_pelandaian"], NUM, "Lazim 3–8"),
        ("Porsi pemandangan dlm faktor lantai", p["faktor_view"]["porsi_view_dalam_faktor_lantai"],
         PCT1, "27% — Nase, van Assendelft & Remoy (2019). Mencegah hitung ganda."),
    ]:
        label(ws, r, nama)
        isi(ws, r, 2, val, "input", fmt, catatan=cat, cat_col=4)
        A[nama] = f"$B${r}"; r += 1
    A["theta"] = A["theta — kekuatan premi vertikal"]
    A["lantai_ref"] = A["Lantai referensi"]
    A["lambda"] = A["lambda — parameter pelandaian"]
    A["porsi_view"] = A["Porsi pemandangan dlm faktor lantai"]
    r += 1

    subjudul(ws, f"A{r}", "E. FAKTOR UKURAN UNIT", span=4); r += 1
    for nama, key, fmt, cat in [
        ("Luas unit referensi (m2)", "luas_referensi_m2", RP, "Faktor = 1,0000 pada luas ini"),
        ("sigma — kekuatan diskon ukuran", "sigma", FAK, "Rumus 10.3. Lazim 0,02–0,06"),
        ("Batas bawah faktor ukuran", "batas_bawah", FAK, None),
        ("Batas atas faktor ukuran", "batas_atas", FAK, None),
    ]:
        label(ws, r, nama)
        isi(ws, r, 2, fu[key], "input", fmt, catatan=cat, cat_col=4)
        A["uk_" + key] = f"$B${r}"; r += 1
    r += 1

    subjudul(ws, f"A{r}", "F. KEUANGAN GEDUNG", span=4); r += 1
    for nama, key, fmt, cat in [
        ("Nilai aset gedung (Rp)", "nilai_aset_rp", RP, "Nilai perolehan atau nilai pasar terkini"),
        ("Cap rate target", "cap_rate_target", PCT2, "Rumus 6.4"),
        ("Biaya operasional tahunan (Rp)", "opex_tahunan_rp", RP, "Yang ditanggung pemilik"),
        ("Pendapatan lain tahunan (Rp)", "pendapatan_lain_tahunan_rp", RP, "Parkir, antena, iklan"),
        ("Cadangan belanja modal tahunan (Rp)", "cadangan_capex_tahunan_rp", RP, "Rumus 6.6"),
        ("Cicilan utang tahunan (Rp)", "cicilan_utang_tahunan_rp", RP, "Rumus 6.6"),
        ("Okupansi target", "okupansi_target", PCT1, "Acuan CBRE: CBD menuju ~78%"),
        ("Kerugian penagihan", "kerugian_penagihan", PCT2, "Tunggakan dan piutang tak tertagih"),
        ("Tingkat diskonto tahunan", "diskonto_tahunan", PCT1, "Rumus 14.3 dan 15.3"),
        ("Eskalasi sewa tahunan", "eskalasi_sewa_tahunan", PCT1,
         "Proyeksi pasar Jakarta 2%–3% per tahun (Colliers, CBRE)"),
        ("Eskalasi service charge tahunan", "eskalasi_sc_tahunan", PCT1,
         "Proyeksi Colliers ~3% per tahun sampai 2029"),
    ]:
        label(ws, r, nama)
        isi(ws, r, 2, k[key], "input", fmt, kunci=(key in ("cap_rate_target", "okupansi_target")),
            catatan=cat, cat_col=4)
        A["k_" + key] = f"$B${r}"; r += 1
    r += 1

    subjudul(ws, f"A{r}", "G. PAJAK  (verifikasi ke sumber resmi saat digunakan)", span=4); r += 1
    label(ws, r, "PPh Final sewa tanah/bangunan")
    isi(ws, r, 2, pj["pph_final_sewa"], "input", PCT1, kunci=True,
        catatan="PP 34/2017 — 10% dari jumlah bruto TERMASUK service charge", cat_col=4)
    A["pph"] = f"$B${r}"; r += 1
    label(ws, r, "Tarif PPN")
    isi(ws, r, 2, pj["ppn"], "input", PCT1, kunci=True,
        catatan="Periksa tarif yang berlaku saat digunakan", cat_col=4)
    A["ppn"] = f"$B${r}"; r += 2

    subjudul(ws, f"A{r}", "H. INSENTIF DAN FIT-OUT", span=4); r += 1
    for nama, val, fmt, cat in [
        ("Masa sewa baku (bulan)", ins["masa_sewa_baku_bulan"], NUM, "Rumus 14.1"),
        ("Bulan bebas sewa baku", ins["bulan_gratis_baku"], NUM, "Rumus 14.1"),
        ("Biaya perbaikan ruang / TI (Rp/m2)", ins["biaya_ti_rp_m2"], RP, "Ditanggung pemilik"),
        ("Komisi agen (% nilai kontrak)", ins["komisi_agen_persen_nilai_kontrak"], PCT1, None),
        ("Biaya fit-out penuh (Rp/m2)", fk["biaya_fitout_rp_m2"], RP, "Untuk uji Rumus 10.5"),
        ("Masa sewa acuan fit-out (bulan)", fk["masa_sewa_acuan_bulan"], NUM, "Rumus 10.5"),
    ]:
        label(ws, r, nama)
        isi(ws, r, 2, val, "input", fmt, catatan=cat, cat_col=4)
        A[nama] = f"$B${r}"; r += 1
    A["masa_sewa"] = A["Masa sewa baku (bulan)"]
    A["bulan_gratis"] = A["Bulan bebas sewa baku"]
    A["ti_m2"] = A["Biaya perbaikan ruang / TI (Rp/m2)"]
    A["komisi"] = A["Komisi agen (% nilai kontrak)"]
    A["fitout_m2"] = A["Biaya fit-out penuh (Rp/m2)"]
    A["fitout_bulan"] = A["Masa sewa acuan fit-out (bulan)"]
    r += 1

    subjudul(ws, f"A{r}", "I. SENSITIVITAS", span=4); r += 1
    label(ws, r, "Elastisitas okupansi terhadap harga")
    isi(ws, r, 2, p["sensitivitas"]["elastisitas_okupansi"], "input", FAK,
        catatan="Rumus 16.3. Nilai mutlak < 1 berarti kenaikan tarif menambah pendapatan.", cat_col=4)
    A["elastisitas"] = f"$B${r}"; r += 2

    subjudul(ws, f"A{r}", "J. AMBANG PEMERIKSAAN MUTU", span=4); r += 1
    for nama, key, fmt in [
        ("Toleransi kalibrasi", "toleransi_kalibrasi", PCT2),
        ("CV pembanding maksimum", "cv_pembanding_maks", PCT1),
        ("Penyesuaian pembanding maksimum", "penyesuaian_pembanding_maks", PCT1),
        ("Selisih pembulatan maksimum", "selisih_pembulatan_maks", PCT2),
        ("Faktor kalibrasi k minimum", "kalibrasi_k_min", FAK),
        ("Faktor kalibrasi k maksimum", "kalibrasi_k_maks", FAK),
    ]:
        label(ws, r, nama)
        isi(ws, r, 2, am[key], "input", fmt)
        A["am_" + key] = f"$B${r}"; r += 1

    normalkan_font(ws)
    ws.freeze_panes = "A4"
    return ws


# ============================================================================
def bangun_faktor(wb, p):
    ws = wb.create_sheet("03_FAKTOR")
    lebar(ws, {"A": 26, "B": 14, "C": 14, "D": 14, "E": 16, "F": 60})
    judul(ws, "A1", "03 — TABEL ACUAN FAKTOR PENGALI", span=6)
    ws["A2"] = "Ubah nilai premi di sini untuk menyetel model. Seluruh angka WAJIB dikalibrasi dengan data setempat."
    ws["A2"].font = Font(name=FONT, size=9, italic=True)

    # --- Zona lantai: baris 5..(5+n-1)
    subjudul(ws, "A4", "TABEL 1 — ZONA LANTAI  (Rumus 9.1)", span=6)
    header_baris(ws, 5, ["Nama zona", "Lantai awal", "Lantai akhir",
                         "Premi zona", "Tambahan/lantai", "Dasar pertimbangan"])
    catatan_zona = [
        "Kebisingan jalan, pemandangan terhalang; namun akses lobi tercepat.",
        "Zona acuan — premi ditetapkan nol.",
        "Di atas garis atap gedung sekitar; pemandangan mulai terbuka.",
        "Pemandangan penuh, kebisingan minimal.",
        "Lantai penanda, gengsi tertinggi; premi melandai (Chau dkk. 2012).",
    ]
    z0 = 6
    for i, z in enumerate(p["faktor_lantai"]["zona"]):
        rr = z0 + i
        isi(ws, rr, 1, z["nama"], "input")
        isi(ws, rr, 2, z["lantai_awal"], "input", NUM)
        isi(ws, rr, 3, z["lantai_akhir"], "input", NUM)
        isi(ws, rr, 4, z["premi_zona"], "input", PCT2)
        isi(ws, rr, 5, z["tambahan_per_lantai"], "input", PCT2)
        ws.cell(row=rr, column=6, value=catatan_zona[i]).font = Font(
            name=FONT, size=8, italic=True, color="595959")
    nz = len(p["faktor_lantai"]["zona"])
    Z = {
        "awal": f"'03_FAKTOR'!$B${z0}:$B${z0+nz-1}",
        "akhir": f"'03_FAKTOR'!$C${z0}:$C${z0+nz-1}",
        "premi": f"'03_FAKTOR'!$D${z0}:$D${z0+nz-1}",
        "tambah": f"'03_FAKTOR'!$E${z0}:$E${z0+nz-1}",
        "nama": f"'03_FAKTOR'!$A${z0}:$A${z0+nz-1}",
    }

    r = z0 + nz + 1
    subjudul(ws, f"A{r}", "TABEL 2 — KATEGORI PEMANDANGAN  (Rumus 10.1)", span=6); r += 1
    header_baris(ws, r, ["Kategori", "Premi", "", "", "", "Definisi objektif"]); r += 1
    v0 = r
    def_view = {
        "Terhalang": "Jarak pandang bebas kurang dari 30 meter.",
        "Terbatas": "Jarak pandang bebas 30–150 meter.",
        "Terbuka": "Jarak pandang bebas di atas 150 meter tanpa penghalang utama.",
        "Penanda": "Menghadap objek bernilai: taman kota, sungai, tugu, garis langit.",
    }
    for nama, val in p["faktor_view"]["kategori"].items():
        isi(ws, r, 1, nama, "input")
        isi(ws, r, 2, val, "input", PCT2)
        ws.cell(row=r, column=6, value=def_view[nama]).font = Font(
            name=FONT, size=8, italic=True, color="595959")
        r += 1
    nv = len(p["faktor_view"]["kategori"])
    V = {"nama": f"'03_FAKTOR'!$A${v0}:$A${v0+nv-1}",
         "premi": f"'03_FAKTOR'!$B${v0}:$B${v0+nv-1}"}

    r += 1
    subjudul(ws, f"A{r}", "TABEL 3 — POSISI DALAM DENAH LANTAI  (Rumus 10.2)", span=6); r += 1
    header_baris(ws, r, ["Kode posisi", "Premi", "", "", "", "Alasan"]); r += 1
    p0 = r
    def_pos = {
        "Sudut": "Jendela di dua sisi; cahaya alami dua arah, kesan lapang.",
        "Hadap_Lift": "Mudah ditemukan tamu; cocok untuk kantor dengan banyak kunjungan.",
        "Dekat_Servis": "Potensi kebisingan dan getaran dari ruang mesin.",
        "Ujung_Buntu": "Akses lebih jauh, sirkulasi kurang baik.",
        "Standar": "Kondisi acuan.",
    }
    for nama, val in p["faktor_posisi"].items():
        isi(ws, r, 1, nama, "input")
        isi(ws, r, 2, val, "input", PCT2)
        ws.cell(row=r, column=6, value=def_pos[nama]).font = Font(
            name=FONT, size=8, italic=True, color="595959")
        r += 1
    npos = len(p["faktor_posisi"])
    P_ = {"nama": f"'03_FAKTOR'!$A${p0}:$A${p0+npos-1}",
          "premi": f"'03_FAKTOR'!$B${p0}:$B${p0+npos-1}"}

    r += 1
    subjudul(ws, f"A{r}", "TABEL 4 — KONDISI FIT-OUT  (Rumus 10.4)", span=6); r += 1
    header_baris(ws, r, ["Kondisi", "Premi", "", "", "", "Keterangan"]); r += 1
    kd0 = r
    def_kon = {
        "Shell_Core": "Polos: struktur, lantai beton, belum ada interior. Kondisi acuan.",
        "Warm_Shell": "Plafon, lantai, dan listrik dasar sudah terpasang.",
        "Semi_Fitted": "Partisi dasar dan pantry sudah tersedia.",
        "Fully_Fitted": "Siap huni termasuk perabot. Uji dengan Rumus 10.5.",
    }
    for nama in ["Shell_Core", "Warm_Shell", "Semi_Fitted", "Fully_Fitted"]:
        isi(ws, r, 1, nama, "input")
        isi(ws, r, 2, p["faktor_kondisi"][nama], "input", PCT2)
        ws.cell(row=r, column=6, value=def_kon[nama]).font = Font(
            name=FONT, size=8, italic=True, color="595959")
        r += 1
    K_ = {"nama": f"'03_FAKTOR'!$A${kd0}:$A${kd0+3}",
          "premi": f"'03_FAKTOR'!$B${kd0}:$B${kd0+3}",
          "fully": f"'03_FAKTOR'!$B${kd0+3}"}

    r += 1
    subjudul(ws, f"A{r}", "TABEL 5 — EFISIENSI DENAH  (Rumus 10.6)", span=6); r += 1
    header_baris(ws, r, ["Karakteristik", "Premi", "", "", "", "Keterangan"]); r += 1
    d0 = r
    def_den = {
        "Bebas_Kolom": "Denah tanpa kolom di dalam unit; tata ruang paling luwes.",
        "Standar": "Kondisi acuan.",
        "Banyak_Kolom": "Banyak kolom atau bentuk tidak beraturan.",
        "Plafon_Tinggi": "Tinggi plafon di atas 2,90 meter.",
    }
    for nama in ["Bebas_Kolom", "Standar", "Banyak_Kolom", "Plafon_Tinggi"]:
        isi(ws, r, 1, nama, "input")
        isi(ws, r, 2, p["faktor_denah"][nama], "input", PCT2)
        ws.cell(row=r, column=6, value=def_den[nama]).font = Font(
            name=FONT, size=8, italic=True, color="595959")
        r += 1
    D_ = {"nama": f"'03_FAKTOR'!$A${d0}:$A${d0+3}",
          "premi": f"'03_FAKTOR'!$B${d0}:$B${d0+3}"}

    r += 2
    ws.cell(row=r, column=1,
            value="Landasan empiris: Nutt (2016, MIT) — premi lantai positif di 23 dari 25 kota; "
                  "Nase dkk. (2019) — 27% premi vertikal berasal dari pemandangan; "
                  "Koster dkk. (2014) — ~4% per 10 m tinggi gedung; "
                  "Chau dkk. (2012) — premi lantai mengecil di ketinggian. "
                  "Rincian dan tautan pada lembar 11_SUMBER.").font = Font(
        name=FONT, size=8, italic=True, color="595959")

    normalkan_font(ws)
    return ws, Z, V, P_, K_, D_


# ============================================================================
def data_unit_dummy(p):
    """Menghasilkan daftar unit dummy yang menyerupai gedung nyata."""
    rnd = random.Random(20260823)
    g = p["gedung"]
    lantai_mulai = g["lantai_sewa_mulai"]
    lantai_akhir = g["jumlah_lantai"]
    nla_target = g["nla_m2"]
    n_lantai = lantai_akhir - lantai_mulai + 1
    nla_per_lantai = nla_target / n_lantai   # 1200 m2

    views = ["Terhalang", "Terbatas", "Terbuka", "Penanda"]
    posisi_opsi = ["Sudut", "Hadap_Lift", "Dekat_Servis", "Ujung_Buntu", "Standar"]
    kondisi_opsi = ["Shell_Core", "Warm_Shell", "Semi_Fitted", "Fully_Fitted"]
    denah_opsi = ["Bebas_Kolom", "Standar", "Banyak_Kolom", "Plafon_Tinggi"]

    penyewa = ["PT Andalan Digital", "PT Sinar Kencana", "Kantor Hukum Wijaya & Rekan",
               "PT Bahari Logistik", "PT Nusantara Fintech", "PT Graha Konsultama",
               "PT Mitra Energi Terbarukan", "PT Cakrawala Media", "PT Sentosa Asuransi",
               "PT Dirgantara Teknologi", "PT Bumi Sejahtera", "PT Lintas Data Prima",
               "PT Karya Arsitektur", "PT Samudera Trading", "PT Rekayasa Presisi"]

    unit = []
    for lt in range(lantai_mulai, lantai_akhir + 1):
        # jumlah unit per lantai: lantai atas cenderung lebih sedikit (unit besar)
        if lt >= 28:
            n = 1
        elif lt >= 21:
            n = rnd.choice([1, 2, 2])
        elif lt >= 13:
            n = rnd.choice([2, 2, 3])
        else:
            n = rnd.choice([2, 3, 3, 4])

        # bagi luas lantai
        bagian = [rnd.uniform(0.8, 1.2) for _ in range(n)]
        tot = sum(bagian)
        luas = [round(nla_per_lantai * b / tot / 5) * 5 for b in bagian]
        selisih = round(nla_per_lantai) - sum(luas)
        luas[0] += selisih

        for i in range(n):
            kode = f"{g['kode']}-{lt:02d}{chr(65 + i)}"
            # view berkorelasi dengan lantai
            if lt <= 5:
                v = rnd.choice(["Terhalang", "Terhalang", "Terbatas"])
            elif lt <= 12:
                v = rnd.choice(["Terhalang", "Terbatas", "Terbatas", "Terbuka"])
            elif lt <= 20:
                v = rnd.choice(["Terbatas", "Terbuka", "Terbuka"])
            elif lt <= 27:
                v = rnd.choice(["Terbuka", "Terbuka", "Penanda"])
            else:
                v = rnd.choice(["Terbuka", "Penanda", "Penanda"])

            if n == 1:
                pos = "Sudut"
            elif i == 0:
                pos = rnd.choice(["Sudut", "Sudut", "Hadap_Lift"])
            elif i == n - 1:
                pos = rnd.choice(["Ujung_Buntu", "Standar", "Sudut"])
            else:
                pos = rnd.choice(["Standar", "Standar", "Dekat_Servis", "Hadap_Lift"])

            kon = rnd.choices(kondisi_opsi, weights=[35, 30, 22, 13])[0]
            den = rnd.choices(denah_opsi, weights=[18, 58, 16, 8])[0]

            terisi = rnd.random() < 0.78
            unit.append({
                "gedung": g["kode"],
                "kode": kode,
                "lantai": lt,
                "luas": luas[i],
                "view": v,
                "posisi": pos,
                "kondisi": kon,
                "denah": den,
                "status": "Terisi" if terisi else "Kosong",
                "penyewa": rnd.choice(penyewa) if terisi else "",
            })
    return unit


def bangun_master_unit(wb, p, unit):
    ws = wb.create_sheet("02_MASTER_UNIT")
    lebar(ws, {"A": 12, "B": 14, "C": 9, "D": 12, "E": 14, "F": 14, "G": 14,
               "H": 14, "I": 14, "J": 12, "K": 30, "L": 26})
    judul(ws, "A1", "02 — DAFTAR UNIT DAN ATRIBUTNYA", span=12)
    ws["A2"] = ("Ganti isi tabel ini dengan data gedung Anda. Baris pertama di bawah kepala tabel "
                "adalah CONTOH format yang benar. Seluruh kolom bertanda * wajib diisi.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True)

    kolom = ["Kode_Gedung *", "Kode_Unit *", "Lantai *", "Luas_NLA_m2 *",
             "Kategori_View *", "Posisi *", "Kondisi_Fitout *", "Denah *",
             "Status_Hunian", "Nama_Penyewa", "Catatan"]
    header_baris(ws, 4, kolom)

    r = 5
    for u in unit:
        isi(ws, r, 1, u["gedung"], "input")
        isi(ws, r, 2, u["kode"], "input")
        isi(ws, r, 3, u["lantai"], "input", NUM)
        isi(ws, r, 4, u["luas"], "input", RP)
        isi(ws, r, 5, u["view"], "input")
        isi(ws, r, 6, u["posisi"], "input")
        isi(ws, r, 7, u["kondisi"], "input")
        isi(ws, r, 8, u["denah"], "input")
        isi(ws, r, 9, u["status"], "input")
        isi(ws, r, 10, u["penyewa"], "input")
        isi(ws, r, 11, "", "input")
        r += 1

    baris_akhir = r - 1
    ws.cell(row=r + 1, column=1, value="TOTAL").font = Font(name=FONT, size=10, bold=True)
    c = ws.cell(row=r + 1, column=4, value=f"=SUM(D5:D{baris_akhir})")
    c.font = Font(name=FONT, size=10, bold=True)
    c.number_format = RP
    ws.cell(row=r + 1, column=3, value=f"=COUNTA(B5:B{baris_akhir})").number_format = NUM
    ws.cell(row=r + 2, column=1,
            value="Catatan: Total luas di atas harus sama dengan NLA pada lembar 01_ASUMSI. "
                  "Bila berbeda, salah satu datanya perlu diperbaiki.").font = Font(
        name=FONT, size=8, italic=True, color="C00000")

    ws.freeze_panes = "C5"
    ws.auto_filter.ref = f"A4:K{baris_akhir}"
    normalkan_font(ws)
    return ws, baris_akhir


# ============================================================================
def bangun_kalkulasi(wb, p, n_unit, Z, V, P_, K_, D_):
    ws = wb.create_sheet("04_KALKULASI")
    judul(ws, "A1", "04 — MESIN PERHITUNGAN TARIF PER UNIT  (JANGAN DIUBAH)", span=27)
    ws["A2"] = ("Seluruh sel di lembar ini berisi rumus. Mengganti rumus dengan angka akan merusak model. "
                "Untuk menyetel hasil, ubah lembar 01_ASUMSI atau 03_FAKTOR.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True, color="C00000")

    # Blok kalibrasi di bagian atas
    subjudul(ws, "A4", "BLOK KALIBRASI  (Rumus 11.1)", span=6)
    r0 = 9                      # baris pertama data
    r1 = r0 + n_unit - 1        # baris terakhir data

    label(ws, 5, "Rata-rata tertimbang tarif awal (Rp/m2/bln)")
    ws["E5"] = f"=IFERROR(SUMPRODUCT($C${r0}:$C${r1},$Q${r0}:$Q${r1})/SUM($C${r0}:$C${r1}),0)"
    ws["E5"].font = Font(name=FONT, size=10, color=C_FORMULA)
    ws["E5"].number_format = RP

    label(ws, 6, "Tarif dasar gedung R* (Rp/m2/bln)")
    ws["E6"] = f"='01_ASUMSI'!{A['R_bintang']}"
    ws["E6"].font = Font(name=FONT, size=10, color=C_LINK)
    ws["E6"].number_format = RP

    label(ws, 7, "FAKTOR KALIBRASI  k", bold=True)
    ws["E7"] = "=IFERROR($E$6/$E$5,1)"
    ws["E7"].font = Font(name=FONT, size=11, bold=True, color=C_FORMULA)
    ws["E7"].number_format = FAK
    ws["E7"].fill = PatternFill("solid", fgColor=F_KUNCI)
    ws["F7"] = "Sehat pada rentang 0,90–1,10. Di luar itu, komposisi unit terlalu berat sebelah."
    ws["F7"].font = Font(name=FONT, size=8, italic=True, color="595959")

    kolom = [
        "Kode_Unit", "Lantai", "Luas m2", "Zona",                       # A B C D
        "F lantai ZONA", "F lantai LOG", "F lantai DIPAKAI",            # E F G
        "premi view", "F view", "F posisi", "F ukuran",                 # H I J K
        "F kondisi", "F denah", "F TOTAL", "F dibatasi",                # L M N O
        "R awal", "R final", "R publikasi", "Tarif kotor",              # P Q R S  -> perbaiki di bawah
    ]
    # susun ulang agar sesuai referensi rumus
    kolom = [
        "Kode_Unit",          # A
        "Lantai",             # B
        "Luas m2",            # C
        "Zona",               # D
        "F lantai ZONA",      # E
        "F lantai LOG",       # F
        "F lantai DIPAKAI",   # G
        "premi view mentah",  # H
        "F view (dikoreksi)", # I
        "F posisi",           # J
        "F ukuran",           # K
        "F kondisi",          # L
        "F denah",            # M
        "F TOTAL",            # N
        "F dibatasi",         # O
        "R awal Rp/m2/bln",   # P
        "R final Rp/m2/bln",  # Q -- catatan: Q dipakai kalibrasi = R awal
        "R publikasi",        # R
        "Tarif kotor",        # S
        "Sewa/bulan Rp",      # T
        "Service charge/bln", # U
        "Tagihan kotor/bln",  # V
        "PPN",                # W
        "Total ke penyewa",   # X
        "PPh Final",          # Y
        "Diterima pemilik",   # Z
        "Status",             # AA
    ]
    header_baris(ws, 8, kolom)

    # PENTING: kalibrasi di E5 memakai kolom Q. Maka Q harus = R awal.
    # Susunan final: P = (tidak dipakai/kosongkan) -> agar konsisten,
    # kita jadikan P = R awal juga tidak perlu. Gunakan:
    #   P = R awal   (pra-kalibrasi)  -> tetapi E5 memakai Q.
    # Solusi: Q = R awal, R = R final, S = R publikasi, dst. Perbaiki header.
    kolom_fix = list(kolom)
    kolom_fix[15] = "cadangan"
    kolom_fix[16] = "R awal Rp/m2/bln"
    kolom_fix[17] = "R final Rp/m2/bln"
    kolom_fix[18] = "R publikasi Rp/m2/bln"
    kolom_fix[19] = "Tarif kotor Rp/m2/bln"
    kolom_fix[20] = "Sewa/bulan Rp"
    kolom_fix[21] = "Service charge/bln"
    kolom_fix[22] = "Tagihan kotor/bln"
    kolom_fix[23] = "PPN"
    kolom_fix[24] = "Total ditagih ke penyewa"
    kolom_fix[25] = "PPh Final"
    kolom_fix[26] = "Diterima pemilik/bln"
    header_baris(ws, 8, kolom_fix)

    for i in range(n_unit):
        r = r0 + i
        m = 5 + i   # baris pada 02_MASTER_UNIT
        f = lambda col, rumus, fmt, warna=C_FORMULA: (
            ws.cell(row=r, column=col, value=rumus),
            setattr(ws.cell(row=r, column=col), "number_format", fmt),
            setattr(ws.cell(row=r, column=col), "font",
                    Font(name=FONT, size=9, color=warna)),
        )

        f(1, f"='02_MASTER_UNIT'!B{m}", "General", C_LINK)
        f(2, f"='02_MASTER_UNIT'!C{m}", NUM, C_LINK)
        f(3, f"='02_MASTER_UNIT'!D{m}", RP, C_LINK)
        # Zona
        f(4, f"=INDEX({Z['nama']},MATCH($B{r},{Z['awal']},1))", "General")
        # F lantai zona
        f(5, (f"=1+INDEX({Z['premi']},MATCH($B{r},{Z['awal']},1))"
              f"+INDEX({Z['tambah']},MATCH($B{r},{Z['awal']},1))"
              f"*($B{r}-INDEX({Z['awal']},MATCH($B{r},{Z['awal']},1)))"), FAK)
        # F lantai logaritmik
        f(6, (f"=1+'01_ASUMSI'!{A['theta']}*LN(($B{r}+'01_ASUMSI'!{A['lambda']})"
              f"/('01_ASUMSI'!{A['lantai_ref']}+'01_ASUMSI'!{A['lambda']}))"), FAK)
        # saklar model
        f(7, f'=IF(\'01_ASUMSI\'!{A["model_lantai"]}="ZONA",$E{r},$F{r})', FAK)
        # premi view mentah
        f(8, f"=IFERROR(INDEX({V['premi']},MATCH('02_MASTER_UNIT'!E{m},{V['nama']},0)),0)", PCT2)
        # F view dikoreksi tumpang tindih
        f(9, (f"=1+$H{r}-IF($H{r}>0,MAX(0,$G{r}-1)*'01_ASUMSI'!{A['porsi_view']},0)"), FAK)
        # F posisi
        f(10, f"=1+IFERROR(INDEX({P_['premi']},MATCH('02_MASTER_UNIT'!F{m},{P_['nama']},0)),0)", FAK)
        # F ukuran
        f(11, (f"=MIN('01_ASUMSI'!{A['uk_batas_atas']},MAX('01_ASUMSI'!{A['uk_batas_bawah']},"
               f"IFERROR(('01_ASUMSI'!{A['uk_luas_referensi_m2']}/$C{r})"
               f"^'01_ASUMSI'!{A['uk_sigma']},1)))"), FAK)
        # F kondisi
        f(12, f"=1+IFERROR(INDEX({K_['premi']},MATCH('02_MASTER_UNIT'!G{m},{K_['nama']},0)),0)", FAK)
        # F denah
        f(13, f"=1+IFERROR(INDEX({D_['premi']},MATCH('02_MASTER_UNIT'!H{m},{D_['nama']},0)),0)", FAK)
        # F total
        f(14, f"=$G{r}*$I{r}*$J{r}*$K{r}*$L{r}*$M{r}", FAK)
        # F dibatasi
        f(15, (f"=MIN('01_ASUMSI'!{A['faktor_total_maks']},"
               f"MAX('01_ASUMSI'!{A['faktor_total_min']},$N{r}))"), FAK)
        # cadangan
        ws.cell(row=r, column=16, value="")
        # R awal
        f(17, f"=$E$6*$O{r}", RP)
        # R final
        f(18, f"=$Q{r}*$E$7", RP)
        # R publikasi
        f(19, (f"=ROUND($R{r}/'01_ASUMSI'!{A['mu']},0)*'01_ASUMSI'!{A['mu']}"), RP)
        # tarif kotor
        f(20, f"=$S{r}+'01_ASUMSI'!{A['sc']}", RP)
        # sewa bulanan
        f(21, f"=$S{r}*$C{r}", RP)
        # SC bulanan
        f(22, f"='01_ASUMSI'!{A['sc']}*$C{r}", RP)
        # tagihan kotor
        f(23, f"=$U{r}+$V{r}", RP)
        # PPN
        f(24, f"=$W{r}*'01_ASUMSI'!{A['ppn']}", RP)
        # total ke penyewa
        f(25, f"=$W{r}+$X{r}", RP)
        # PPh final
        f(26, f"=$W{r}*'01_ASUMSI'!{A['pph']}", RP)
        # diterima pemilik
        f(27, f"=$W{r}-$Z{r}", RP)
        # status
        ws.cell(row=r, column=28, value=f"='02_MASTER_UNIT'!I{m}").font = Font(
            name=FONT, size=9, color=C_LINK)

    # header tambahan kolom 28
    hc = ws.cell(row=8, column=28, value="Status hunian")
    hc.font = Font(name=FONT, size=9, bold=True, color="FFFFFF")
    hc.fill = PatternFill("solid", fgColor=F_HEADER)
    hc.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Baris total
    rt = r1 + 2
    ws.cell(row=rt, column=1, value="TOTAL / RATA-RATA").font = Font(name=FONT, size=10, bold=True)
    for col, rumus, fmt in [
        (3, f"=SUM($C${r0}:$C${r1})", RP),
        (19, f"=IFERROR(SUMPRODUCT($C${r0}:$C${r1},$S${r0}:$S${r1})/SUM($C${r0}:$C${r1}),0)", RP),
        (21, f"=SUM($U${r0}:$U${r1})", RP),
        (22, f"=SUM($V${r0}:$V${r1})", RP),
        (23, f"=SUM($W${r0}:$W${r1})", RP),
        (27, f"=SUM($Z${r0}:$Z${r1})", RP),
    ]:
        c = ws.cell(row=rt, column=col, value=rumus)
        c.font = Font(name=FONT, size=10, bold=True)
        c.number_format = fmt
    ws.cell(row=rt + 1, column=1,
            value="Kolom S (R publikasi) rata-rata tertimbang harus mendekati R* pada 01_ASUMSI. "
                  "Selisihnya berasal dari pembulatan dan diperiksa di lembar 09_RINGKASAN.").font = Font(
        name=FONT, size=8, italic=True, color="595959")

    for i in range(1, 29):
        ws.column_dimensions[get_column_letter(i)].width = 13
    ws.column_dimensions["A"].width = 14
    ws.freeze_panes = "D9"
    ws.auto_filter.ref = f"A8:AB{r1}"
    return ws, r0, r1


# ============================================================================
def bangun_pembanding(wb, p):
    ws = wb.create_sheet("05_PEMBANDING")
    lebar(ws, {"A": 10, "B": 26, "C": 10, "D": 15, "E": 11, "F": 11, "G": 11,
               "H": 11, "I": 11, "J": 11, "K": 12, "L": 12, "M": 12, "N": 11,
               "O": 16, "P": 16, "Q": 34})
    judul(ws, "A1", "05 — GRID PENYESUAIAN DATA PEMBANDING PASAR  (Rumus 5.1–5.3)", span=17)
    ws["A2"] = ("Aturan tanda: pembanding LEBIH BAIK dari gedung kita diberi penyesuaian NEGATIF; "
                "pembanding LEBIH BURUK diberi penyesuaian POSITIF.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True)

    header_baris(ws, 4, [
        "Kode", "Nama gedung pembanding", "Grade", "Tarif awal Rp/m2/bln",
        "Adj Lokasi", "Adj Usia", "Adj Grade", "Adj Transit", "Adj Hijau",
        "Adj Fasilitas", "Total bersih", "Total mutlak", "1/(mutlak+eps)",
        "Bobot", "Tarif disesuaikan", "Kontribusi", "Sumber data"])

    data = [
        ("P-01", "Menara Cendrawasih", "A", 195000, 0.00, 0.03, 0.00, -0.04, -0.03, 0.00,
         "Laporan konsultan properti Q2 2026"),
        ("P-02", "Wisma Anggrek", "B+", 165000, 0.05, -0.02, 0.06, 0.02, 0.00, 0.00,
         "Survei langsung, Juni 2026"),
        ("P-03", "Graha Kirana Tower", "A", 210000, -0.06, 0.05, -0.05, -0.05, -0.03, 0.00,
         "Laporan konsultan properti Q2 2026"),
        ("P-04", "Plaza Mahakam", "A-", 172000, 0.02, 0.00, 0.04, 0.00, 0.00, 0.00,
         "Data transaksi internal, Mei 2026"),
        ("P-05", "Menara Bimasakti", "B+", 158000, 0.06, -0.03, 0.07, 0.03, 0.00, 0.02,
         "Survei langsung, Juli 2026"),
        ("P-06", "Sentra Nirwana Office", "A", 188000, 0.01, 0.02, 0.00, -0.02, 0.00, 0.00,
         "Laporan konsultan properti Q2 2026"),
    ]
    r0, r1 = 5, 5 + len(data) - 1
    eps = 0.01
    for i, d in enumerate(data):
        r = r0 + i
        isi(ws, r, 1, d[0], "input")
        isi(ws, r, 2, d[1], "input")
        isi(ws, r, 3, d[2], "input")
        isi(ws, r, 4, d[3], "input", RP, kunci=True)
        for j in range(6):
            isi(ws, r, 5 + j, d[4 + j], "input", PCT1)
        isi(ws, r, 11, f"=SUM($E{r}:$J{r})", "formula", PCT1)
        isi(ws, r, 12, f"=SUMPRODUCT(ABS($E{r}:$J{r}))", "formula", PCT1)
        isi(ws, r, 13, f"=1/($L{r}+{eps})", "formula", NUM)
        isi(ws, r, 14, f"=IFERROR($M{r}/SUM($M${r0}:$M${r1}),0)", "formula", PCT1)
        isi(ws, r, 15,
            f"=$D{r}*(1+$E{r})*(1+$F{r})*(1+$G{r})*(1+$H{r})*(1+$I{r})*(1+$J{r})",
            "formula", RP)
        isi(ws, r, 16, f"=$N{r}*$O{r}", "formula", RP)
        ws.cell(row=r, column=17, value=d[10]).font = Font(
            name=FONT, size=8, italic=True, color="595959")

    r = r1 + 2
    label(ws, r, "TARIF DASAR INDIKASI PASAR  (R pasar)", bold=True)
    c = ws.cell(row=r, column=4, value=f"=SUM($P${r0}:$P${r1})")
    c.font = Font(name=FONT, size=12, bold=True); c.number_format = RP
    c.fill = PatternFill("solid", fgColor=F_KUNCI); c.border = BORDER
    ws.cell(row=r, column=5, value="Rumus 5.3").font = Font(name=FONT, size=8, italic=True)
    R_PASAR = f"'05_PEMBANDING'!$D${r}"

    r += 1
    label(ws, r, "Rata-rata sederhana (pembanding)")
    ws.cell(row=r, column=4, value=f"=AVERAGE($O${r0}:$O${r1})").number_format = RP
    r += 1
    label(ws, r, "Simpangan baku tarif disesuaikan")
    ws.cell(row=r, column=4, value=f"=STDEV($O${r0}:$O${r1})").number_format = RP
    r += 1
    label(ws, r, "Koefisien variasi (Rumus 17.1)")
    cv = ws.cell(row=r, column=4,
                 value=f"=IFERROR(STDEV($O${r0}:$O${r1})/AVERAGE($O${r0}:$O${r1}),1)")
    cv.number_format = PCT1
    CV_CELL = f"'05_PEMBANDING'!$D${r}"
    ws.cell(row=r, column=5, value="Ambang: maksimal 15%").font = Font(name=FONT, size=8, italic=True)
    r += 1
    label(ws, r, "Penyesuaian mutlak terbesar")
    mx = ws.cell(row=r, column=4, value=f"=MAX($L${r0}:$L${r1})")
    mx.number_format = PCT1
    MAX_ADJ = f"'05_PEMBANDING'!$D${r}"
    ws.cell(row=r, column=5, value="Ambang: maksimal 25%").font = Font(name=FONT, size=8, italic=True)
    r += 1
    label(ws, r, "Jumlah pembanding")
    ws.cell(row=r, column=4, value=f"=COUNTA($A${r0}:$A${r1})").number_format = NUM
    N_COMP = f"'05_PEMBANDING'!$D${r}"
    ws.cell(row=r, column=5, value="Minimal 4, idealnya 6–8").font = Font(name=FONT, size=8, italic=True)

    r += 2
    ws.cell(row=r, column=1,
            value="Sumber acuan pasar Jakarta: Colliers, Cushman & Wakefield, CBRE, JLL, dan "
                  "Bank Indonesia. Tautan lengkap pada lembar 11_SUMBER. "
                  "Seluruh angka pada tabel ini adalah DATA DUMMY.").font = Font(
        name=FONT, size=8, italic=True, color="C00000")

    normalkan_font(ws)
    ws.freeze_panes = "C5"
    return ws, R_PASAR, CV_CELL, MAX_ADJ, N_COMP


# ============================================================================
def bangun_kelayakan(wb, p, R_PASAR):
    ws = wb.create_sheet("06_UJI_KELAYAKAN")
    lebar(ws, {"A": 48, "B": 8, "C": 22, "D": 58})
    judul(ws, "A1", "06 — UJI KELAYAKAN: PENDEKATAN PENDAPATAN DAN PAGAR PENGAMAN", span=4)

    def baris(r, nama, rumus, fmt, cat=None, warna=C_FORMULA, tebal=False, kunci=False):
        label(ws, r, nama, bold=tebal)
        c = ws.cell(row=r, column=3, value=rumus)
        c.font = Font(name=FONT, size=11 if tebal else 10, bold=tebal, color=warna)
        c.number_format = fmt
        c.border = BORDER
        if kunci:
            c.fill = PatternFill("solid", fgColor=F_KUNCI)
        if cat:
            ws.cell(row=r, column=4, value=cat).font = Font(
                name=FONT, size=8, italic=True, color="595959")
        return c

    subjudul(ws, "A3", "BAGIAN 1 — PENDEKATAN PENDAPATAN  (Rumus 6.1–6.5)", span=4)
    baris(4, "NLA total (m2)", f"='01_ASUMSI'!{A['nla']}", RP, warna=C_LINK)
    baris(5, "Okupansi target", f"='01_ASUMSI'!{A['k_okupansi_target']}", PCT1, warna=C_LINK)
    baris(6, "Kerugian penagihan", f"='01_ASUMSI'!{A['k_kerugian_penagihan']}", PCT2, warna=C_LINK)
    baris(7, "Penyebut efektif  = NLA x (okupansi - kerugian) x 12",
          "=$C$4*($C$5-$C$6)*12", RP, "Meter persegi-bulan yang benar-benar menghasilkan uang")
    baris(8, "Nilai aset (Rp)", f"='01_ASUMSI'!{A['k_nilai_aset_rp']}", RP, warna=C_LINK)
    baris(9, "Cap rate target", f"='01_ASUMSI'!{A['k_cap_rate_target']}", PCT2, warna=C_LINK)
    baris(10, "NOI target (Rp/tahun)", "=$C$8*$C$9", RP, "Rumus 6.4 dibalik")
    baris(11, "Biaya operasional tahunan (Rp)", f"='01_ASUMSI'!{A['k_opex_tahunan_rp']}", RP, warna=C_LINK)
    baris(12, "Pendapatan lain tahunan (Rp)", f"='01_ASUMSI'!{A['k_pendapatan_lain_tahunan_rp']}", RP, warna=C_LINK)
    baris(13, "TARIF YANG DIBUTUHKAN  (R butuh)", "=IFERROR(($C$10+$C$11-$C$12)/$C$7,0)", RP,
          "Rumus 6.5", tebal=True)

    subjudul(ws, "A15", "BAGIAN 2 — TITIK IMPAS  (Rumus 6.6)", span=4)
    baris(16, "Cadangan belanja modal tahunan (Rp)", f"='01_ASUMSI'!{A['k_cadangan_capex_tahunan_rp']}", RP, warna=C_LINK)
    baris(17, "Cicilan utang tahunan (Rp)", f"='01_ASUMSI'!{A['k_cicilan_utang_tahunan_rp']}", RP, warna=C_LINK)
    baris(18, "TARIF TITIK IMPAS  (R impas)",
          "=IFERROR(($C$11+$C$16+$C$17-$C$12)/$C$7,0)", RP,
          "Di bawah angka ini, tiap m2 yang disewakan menambah kerugian", tebal=True)

    subjudul(ws, "A20", "BAGIAN 3 — PAGAR PENGAMAN DAN PENETAPAN TARIF  (Rumus 7.1–7.3)", span=4)
    baris(21, "Tarif indikasi pasar  (R pasar)", f"={R_PASAR}", RP, "Dari lembar 05", warna=C_LINK)
    r = 22
    label(ws, 22, "TARIF DASAR HASIL MODEL  (R*)", bold=True)
    c = ws.cell(row=22, column=3, value="=MEDIAN($C$24,$C$21,$C$25)")
    c.font = Font(name=FONT, size=13, bold=True, color="1F3864")
    c.number_format = RP
    c.fill = PatternFill("solid", fgColor=F_KUNCI)
    c.border = BORDER
    ws.cell(row=22, column=4, value="Rumus 7.3 — median otomatis menjaga tarif di dalam koridor").font = Font(
        name=FONT, size=8, italic=True, color="595959")

    baris(24, "Batas bawah  (R min)",
          f"=MAX($C$18*'01_ASUMSI'!{A['phi_toleransi_impas']},"
          f"$C$21*(1-'01_ASUMSI'!{A['delta_diskon_maks_pasar']}))", RP, "Rumus 7.1")
    baris(25, "Batas atas  (R maks)",
          f"='01_ASUMSI'!{A['tarif_premium_pasar_rp']}*(1+'01_ASUMSI'!{A['gamma_premi_maks']})",
          RP, "Rumus 7.2")

    subjudul(ws, "A27", "BAGIAN 4 — DIAGNOSIS", span=4)
    baris(28, "Tarif dipakai  (R* dari 01_ASUMSI)", f"='01_ASUMSI'!{A['R_bintang']}", RP, warna=C_LINK)
    baris(29, "Selisih terhadap tarif yang dibutuhkan", "=IFERROR($C$28/$C$13-1,0)", PCT1,
          "Negatif berarti target imbal hasil belum tercapai pada tarif ini")
    baris(30, "Selisih terhadap titik impas", "=IFERROR($C$28/$C$18-1,0)", PCT1,
          "Negatif berarti gedung merugi secara kas pada okupansi target")
    baris(31, "Okupansi minimum agar impas",
          "=IFERROR(($C$11+$C$16+$C$17-$C$12)/($C$28*$C$4*12)+$C$6,0)", PCT1,
          "Okupansi yang harus dicapai agar tarif saat ini menutup seluruh biaya")
    baris(32, "Status terhadap koridor",
          '=IF(AND($C$28>=$C$24,$C$28<=$C$25),"DI DALAM KORIDOR","DI LUAR KORIDOR — PERIKSA")',
          "General", tebal=True)
    baris(33, "Status terhadap titik impas",
          f'=IF($C$28>=$C$18*\'01_ASUMSI\'!{A["phi_toleransi_impas"]},"AMAN",'
          f'"DI BAWAH TITIK IMPAS — PERIKSA")', "General", tebal=True)

    ws.cell(row=35, column=1,
            value="Cara membaca: bila tarif yang dibutuhkan jauh di atas indikasi pasar, itu BUKAN "
                  "kesalahan hitung, melainkan temuan penting. Pilihan tindakannya dijelaskan pada "
                  "Bab 6.2 handbook: turunkan target imbal hasil, tekan biaya operasional, naikkan "
                  "okupansi, tambah pendapatan lain, atau tinjau ulang nilai buku aset.").font = Font(
        name=FONT, size=9, italic=True, color="C00000")
    ws.cell(row=35, column=1).alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells("A35:D37")

    normalkan_font(ws)
    return ws, "'06_UJI_KELAYAKAN'!$C$24", "'06_UJI_KELAYAKAN'!$C$18", "'06_UJI_KELAYAKAN'!$C$13"


# ============================================================================
def bangun_ner(wb, p, n_unit, r0k, R_MIN):
    ws = wb.create_sheet("07_NER_INSENTIF")
    lebar(ws, {"A": 14, "B": 11, "C": 15, "D": 11, "E": 12, "F": 16, "G": 16,
               "H": 16, "I": 13, "J": 14, "K": 26})
    judul(ws, "A1", "07 — SEWA EFEKTIF BERSIH (NER) DAN BATAS INSENTIF  (Rumus 14.1, 14.4)", span=11)
    ws["A2"] = ("NER menjawab: berapa tarif riil setelah bulan gratis dan biaya insentif diperhitungkan? "
                "Kolom 'Batas bulan gratis' adalah pagar bagi tim pemasaran saat bernegosiasi.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True)

    label(ws, 4, "Tarif minimum yang dapat diterima (R min)")
    c = ws.cell(row=4, column=3, value=f"={R_MIN}")
    c.font = Font(name=FONT, size=10, bold=True, color=C_LINK); c.number_format = RP
    c.fill = PatternFill("solid", fgColor=F_KUNCI)

    header_baris(ws, 6, [
        "Kode_Unit", "Luas m2", "R publikasi", "Masa sewa bln", "Bulan gratis",
        "Biaya TI total Rp", "Komisi agen Rp", "NER Rp/m2/bln",
        "NER vs R min", "Batas bulan gratis", "Status"])

    r0 = 7
    for i in range(n_unit):
        r = r0 + i
        k = r0k + i   # baris pada 04_KALKULASI
        def g(col, rumus, fmt, warna=C_FORMULA):
            cc = ws.cell(row=r, column=col, value=rumus)
            cc.font = Font(name=FONT, size=9, color=warna)
            cc.number_format = fmt
        g(1, f"='04_KALKULASI'!A{k}", "General", C_LINK)
        g(2, f"='04_KALKULASI'!C{k}", RP, C_LINK)
        g(3, f"='04_KALKULASI'!S{k}", RP, C_LINK)
        g(4, f"='01_ASUMSI'!{A['masa_sewa']}", NUM, C_LINK)
        g(5, f"='01_ASUMSI'!{A['bulan_gratis']}", NUM, C_LINK)
        g(6, f"='01_ASUMSI'!{A['ti_m2']}*$B{r}", RP)
        g(7, f"=$C{r}*$B{r}*$D{r}*'01_ASUMSI'!{A['komisi']}", RP)
        g(8, f"=IFERROR(($C{r}*($D{r}-$E{r})-($F{r}+$G{r})/$B{r})/$D{r},0)", RP)
        g(9, f"=IFERROR($H{r}/$C$4-1,0)", PCT1)
        g(10, f"=IFERROR($D{r}*(1-$C$4/$C{r})-($F{r}+$G{r})/($C{r}*$B{r}),0)", NUM)
        ws.cell(row=r, column=11,
                value=f'=IF($H{r}>=$C$4,"AMAN","NER DI BAWAH BATAS — PERIKSA")').font = Font(
            name=FONT, size=9, color=C_FORMULA)

    r1 = r0 + n_unit - 1
    rt = r1 + 2
    ws.cell(row=rt, column=1, value="RATA-RATA TERTIMBANG").font = Font(name=FONT, size=10, bold=True)
    for col, rumus, fmt in [
        (2, f"=SUM($B${r0}:$B${r1})", RP),
        (8, f"=IFERROR(SUMPRODUCT($B${r0}:$B${r1},$H${r0}:$H${r1})/SUM($B${r0}:$B${r1}),0)", RP),
        (10, f"=IFERROR(SUMPRODUCT($B${r0}:$B${r1},$J${r0}:$J${r1})/SUM($B${r0}:$B${r1}),0)", NUM),
    ]:
        cc = ws.cell(row=rt, column=col, value=rumus)
        cc.font = Font(name=FONT, size=10, bold=True); cc.number_format = fmt
    ws.cell(row=rt + 1, column=1, value=f'=COUNTIF($K${r0}:$K${r1},"AMAN")&" unit AMAN dari "&'
                                        f'COUNTA($K${r0}:$K${r1})&" unit"').font = Font(
        name=FONT, size=9, bold=True)

    ws.freeze_panes = "C7"
    normalkan_font(ws)
    return ws


# ============================================================================
def bangun_sensitivitas(wb, p, R_IMPAS):
    ws = wb.create_sheet("08_SENSITIVITAS")
    lebar(ws, {"A": 30, "B": 18, "C": 18, "D": 18, "E": 18, "F": 18, "G": 18, "H": 40})
    judul(ws, "A1", "08 — ANALISIS SENSITIVITAS DAN SKENARIO  (Rumus 16.1–16.5)", span=8)

    sens = p["sensitivitas"]
    var_t = sens["variasi_tarif"]
    var_o = sens["variasi_okupansi"]

    subjudul(ws, "A3", "TABEL 1 — PENDAPATAN SEWA TAHUNAN (Rp) menurut TARIF x OKUPANSI", span=8)
    ws["A4"] = "Tarif (Rp/m2/bln)  ↓   /   Okupansi  →"
    ws["A4"].font = Font(name=FONT, size=9, bold=True)
    for j, o in enumerate(var_o):
        c = ws.cell(row=4, column=2 + j, value=o)
        c.font = Font(name=FONT, size=10, bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=F_HEADER)
        c.number_format = PCT1
        c.alignment = Alignment(horizontal="center")

    for i, vt in enumerate(var_t):
        r = 5 + i
        c = ws.cell(row=r, column=1, value=f"='01_ASUMSI'!{A['R_bintang']}*(1+{vt})")
        c.font = Font(name=FONT, size=10, bold=True, color=C_LINK)
        c.number_format = RP
        c.fill = PatternFill("solid", fgColor=F_SUBJUDUL)
        for j in range(len(var_o)):
            col = 2 + j
            cc = ws.cell(row=r, column=col,
                         value=f"=$A{r}*'01_ASUMSI'!{A['nla']}*{get_column_letter(col)}$4*12")
            cc.font = Font(name=FONT, size=9)
            cc.number_format = RP
            cc.border = BORDER

    r = 5 + len(var_t) + 1
    ws.cell(row=r, column=1, value="Pendapatan pada titik impas (Rp/tahun)").font = Font(
        name=FONT, size=9, bold=True)
    cc = ws.cell(row=r, column=2,
                 value=f"={R_IMPAS}*'01_ASUMSI'!{A['nla']}*"
                       f"('01_ASUMSI'!{A['k_okupansi_target']}-'01_ASUMSI'!{A['k_kerugian_penagihan']})*12")
    cc.number_format = RP; cc.font = Font(name=FONT, size=9, bold=True)
    ws.cell(row=r, column=3, value="Sel di tabel yang nilainya di bawah angka ini berada di zona rugi.").font = Font(
        name=FONT, size=8, italic=True, color="C00000")

    r += 2
    subjudul(ws, f"A{r}", "TABEL 2 — REVPAM DAN ELASTISITAS  (Rumus 16.2–16.4)", span=8); r += 1
    header_baris(ws, r, ["Perubahan tarif", "Tarif baru", "Okupansi hasil elastisitas",
                         "RevPAM Rp/m2/bln", "Pendapatan tahunan Rp", "Selisih vs dasar",
                         "", "Catatan"])
    rh = r
    r += 1
    r_awal = r
    for vt in var_t:
        ws.cell(row=r, column=1, value=vt).number_format = PCT1
        ws.cell(row=r, column=1).font = Font(name=FONT, size=9, color=C_INPUT)
        ws.cell(row=r, column=2, value=f"='01_ASUMSI'!{A['R_bintang']}*(1+$A{r})").number_format = RP
        ws.cell(row=r, column=3,
                value=f"='01_ASUMSI'!{A['k_okupansi_target']}*(1+$A{r})^'01_ASUMSI'!{A['elastisitas']}"
                ).number_format = PCT1
        ws.cell(row=r, column=4, value=f"=$B{r}*$C{r}").number_format = RP
        ws.cell(row=r, column=5, value=f"=$D{r}*'01_ASUMSI'!{A['nla']}*12").number_format = RP
        for col in range(2, 6):
            ws.cell(row=r, column=col).font = Font(name=FONT, size=9)
        r += 1
    r_akhir = r - 1
    # kolom selisih vs dasar (baris tarif 0%)
    baris_dasar = r_awal + var_t.index(0.00)
    for rr in range(r_awal, r_akhir + 1):
        cc = ws.cell(row=rr, column=6, value=f"=IFERROR($E{rr}/$E${baris_dasar}-1,0)")
        cc.number_format = PCT1; cc.font = Font(name=FONT, size=9)
    ws.cell(row=rh + 1, column=8,
            value="Selama nilai mutlak elastisitas kurang dari 1, kenaikan tarif menaikkan "
                  "pendapatan meskipun okupansi turun.").font = Font(
        name=FONT, size=8, italic=True, color="595959")

    r += 2
    subjudul(ws, f"A{r}", "TABEL 3 — TIGA SKENARIO BAKU", span=8); r += 1
    header_baris(ws, r, ["Skenario", "Delta tarif", "Delta okupansi", "Eskalasi",
                         "Tarif skenario", "Okupansi skenario", "Pendapatan tahun-1 Rp", "Digunakan untuk"])
    r += 1
    guna = {
        "Konservatif": "Uji ketahanan; dasar perhitungan kovenan utang.",
        "Dasar": "Anggaran resmi.",
        "Optimistis": "Perencanaan kapasitas dan investasi.",
    }
    for nama, s in sens["skenario"].items():
        ws.cell(row=r, column=1, value=nama).font = Font(name=FONT, size=10, bold=True)
        isi(ws, r, 2, s["delta_tarif"], "input", PCT1)
        isi(ws, r, 3, s["delta_okupansi"], "input", PCT1)
        isi(ws, r, 4, s["eskalasi"], "input", PCT1)
        ws.cell(row=r, column=5, value=f"='01_ASUMSI'!{A['R_bintang']}*(1+$B{r})").number_format = RP
        ws.cell(row=r, column=6, value=f"='01_ASUMSI'!{A['k_okupansi_target']}+$C{r}").number_format = PCT1
        ws.cell(row=r, column=7,
                value=f"=$E{r}*'01_ASUMSI'!{A['nla']}*$F{r}*12").number_format = RP
        for col in (5, 6, 7):
            ws.cell(row=r, column=col).font = Font(name=FONT, size=9)
        ws.cell(row=r, column=8, value=guna[nama]).font = Font(
            name=FONT, size=8, italic=True, color="595959")
        r += 1

    r += 1
    subjudul(ws, f"A{r}", "TABEL 4 — PROYEKSI 5 TAHUN DENGAN ESKALASI  (Rumus 15.1)", span=8); r += 1
    header_baris(ws, r, ["Tahun", "Tarif sewa Rp/m2/bln", "Service charge Rp/m2/bln",
                         "Tarif kotor", "Pendapatan sewa tahunan Rp", "Nilai kini Rp", "", ""])
    r += 1
    rp0 = r
    for n in range(1, 6):
        ws.cell(row=r, column=1, value=n).number_format = NUM
        ws.cell(row=r, column=2,
                value=f"='01_ASUMSI'!{A['R_bintang']}*(1+'01_ASUMSI'!{A['k_eskalasi_sewa_tahunan']})^($A{r}-1)"
                ).number_format = RP
        ws.cell(row=r, column=3,
                value=f"='01_ASUMSI'!{A['sc']}*(1+'01_ASUMSI'!{A['k_eskalasi_sc_tahunan']})^($A{r}-1)"
                ).number_format = RP
        ws.cell(row=r, column=4, value=f"=$B{r}+$C{r}").number_format = RP
        ws.cell(row=r, column=5,
                value=f"=$B{r}*'01_ASUMSI'!{A['nla']}*'01_ASUMSI'!{A['k_okupansi_target']}*12"
                ).number_format = RP
        ws.cell(row=r, column=6,
                value=f"=$E{r}/(1+'01_ASUMSI'!{A['k_diskonto_tahunan']})^$A{r}").number_format = RP
        for col in range(1, 7):
            ws.cell(row=r, column=col).font = Font(name=FONT, size=9)
        r += 1
    ws.cell(row=r, column=1, value="TOTAL").font = Font(name=FONT, size=10, bold=True)
    for col in (5, 6):
        cc = ws.cell(row=r, column=col, value=f"=SUM({get_column_letter(col)}{rp0}:{get_column_letter(col)}{r-1})")
        cc.number_format = RP; cc.font = Font(name=FONT, size=10, bold=True)

    normalkan_font(ws)
    return ws


# ============================================================================
def bangun_ringkasan(wb, p, n_unit, r0k, r1k, R_PASAR, CV_CELL, MAX_ADJ, N_COMP, Z, K_):
    ws = wb.create_sheet("09_RINGKASAN")
    lebar(ws, {"A": 46, "B": 22, "C": 20, "D": 16, "E": 16, "F": 44})
    judul(ws, "A1", "09 — PAPAN PANTAU DAN PEMERIKSAAN MUTU MODEL", span=6)

    K = "'04_KALKULASI'"
    subjudul(ws, "A3", "BAGIAN 1 — RINGKASAN KINERJA", span=6)

    def b(r, nama, rumus, fmt, cat=None, warna=C_LINK, tebal=False):
        label(ws, r, nama, bold=tebal)
        c = ws.cell(row=r, column=2, value=rumus)
        c.font = Font(name=FONT, size=11 if tebal else 10, bold=tebal, color=warna)
        c.number_format = fmt; c.border = BORDER
        if cat:
            ws.cell(row=r, column=6, value=cat).font = Font(
                name=FONT, size=8, italic=True, color="595959")
        return c

    b(4, "Nama gedung", f"='01_ASUMSI'!$B$6", "General")
    b(5, "Jumlah unit", f"=COUNTA({K}!$A${r0k}:$A${r1k})", NUM)
    b(6, "Total NLA (m2)", f"=SUM({K}!$C${r0k}:$C${r1k})", RP)
    b(7, "Tarif dasar gedung R* (Rp/m2/bln)", f"='01_ASUMSI'!{A['R_bintang']}", RP, tebal=True)
    b(8, "Tarif publikasi rata-rata tertimbang",
      f"=IFERROR(SUMPRODUCT({K}!$C${r0k}:$C${r1k},{K}!$S${r0k}:$S${r1k})/SUM({K}!$C${r0k}:$C${r1k}),0)",
      RP, "Harus mendekati R*", warna=C_FORMULA)
    b(9, "Tarif terendah / tertinggi",
      f'=TEXT(MIN({K}!$S${r0k}:$S${r1k}),"#,##0")&"  s.d.  "&TEXT(MAX({K}!$S${r0k}:$S${r1k}),"#,##0")',
      "General", warna=C_FORMULA)
    b(10, "Faktor kalibrasi k", f"={K}!$E$7", FAK, "Sehat pada 0,90–1,10")
    b(11, "Service charge (Rp/m2/bln)", f"='01_ASUMSI'!{A['sc']}", RP)
    b(12, "Tarif kotor rata-rata (Rp/m2/bln)", f"=$B$8+$B$11", RP, warna=C_FORMULA)
    b(13, "Potensi pendapatan kotor tahunan (Rp)",
      f"=$B$8*$B$6*12", RP, "PGI — Rumus 6.1", warna=C_FORMULA)
    b(14, "Pendapatan pada okupansi target (Rp/thn)",
      f"=$B$13*'01_ASUMSI'!{A['k_okupansi_target']}", RP, warna=C_FORMULA)
    b(15, "RevPAM (Rp/m2/bln)",
      f"=$B$8*'01_ASUMSI'!{A['k_okupansi_target']}", RP, "Rumus 16.2", warna=C_FORMULA)
    b(16, "Okupansi aktual (dari data unit)",
      f'=IFERROR(SUMIFS({K}!$C${r0k}:$C${r1k},{K}!$AB${r0k}:$AB${r1k},"Terisi")'
      f"/SUM({K}!$C${r0k}:$C${r1k}),0)", PCT1, warna=C_FORMULA)

    subjudul(ws, "A18", "BAGIAN 2 — TARIF RATA-RATA PER ZONA LANTAI", span=6)
    header_baris(ws, 19, ["Zona", "Jumlah unit", "Total NLA m2",
                          "Tarif rata-rata Rp/m2/bln", "Faktor lantai rata-rata", "Catatan"])
    zona_nama = [z["nama"] for z in p["faktor_lantai"]["zona"]]
    r = 20
    for zn in zona_nama:
        ws.cell(row=r, column=1, value=zn).font = Font(name=FONT, size=10, bold=True)
        ws.cell(row=r, column=2, value=f'=COUNTIFS({K}!$D${r0k}:$D${r1k},$A{r})').number_format = NUM
        ws.cell(row=r, column=3, value=f'=SUMIFS({K}!$C${r0k}:$C${r1k},{K}!$D${r0k}:$D${r1k},$A{r})').number_format = RP
        ws.cell(row=r, column=4,
                value=f'=IFERROR(SUMPRODUCT(({K}!$D${r0k}:$D${r1k}=$A{r})*{K}!$C${r0k}:$C${r1k}*'
                      f'{K}!$S${r0k}:$S${r1k})/$C{r},0)').number_format = RP
        ws.cell(row=r, column=5,
                value=f'=IFERROR(AVERAGEIFS({K}!$G${r0k}:$G${r1k},{K}!$D${r0k}:$D${r1k},$A{r}),0)'
                ).number_format = FAK
        for col in range(2, 6):
            ws.cell(row=r, column=col).font = Font(name=FONT, size=9)
        r += 1
    r_zona_awal, r_zona_akhir = 20, r - 1
    ws.cell(row=r, column=1, value="Tarif rata-rata harus naik dari zona bawah ke zona atas. "
                                   "Bila tidak, periksa faktor lantai.").font = Font(
        name=FONT, size=8, italic=True, color="595959")

    r += 2
    subjudul(ws, f"A{r}", "BAGIAN 3 — SEMBILAN PEMERIKSAAN MUTU  (Bab 17)", span=6); r += 1
    header_baris(ws, r, ["No dan nama pemeriksaan", "Nilai terukur", "Ambang",
                         "STATUS", "", "Tindakan bila PERIKSA"]); r += 1

    cek = [
        ("1. Selisih kalibrasi rata-rata",
         f"=IFERROR(ABS($B$8-$B$7)/$B$7,1)", PCT2,
         f"='01_ASUMSI'!{A['am_toleransi_kalibrasi']}", PCT2, "<=",
         "Perkecil satuan pembulatan pada 01_ASUMSI."),
        ("2. Faktor total minimum",
         f"=MIN({K}!$N${r0k}:$N${r1k})", FAK,
         f"='01_ASUMSI'!{A['faktor_total_min']}", FAK, ">=",
         "Ada faktor yang terlalu menekan. Periksa tumpang tindih di 03_FAKTOR."),
        ("3. Faktor total maksimum",
         f"=MAX({K}!$N${r0k}:$N${r1k})", FAK,
         f"='01_ASUMSI'!{A['faktor_total_maks']}", FAK, "<=",
         "Ada faktor yang terlalu agresif. Periksa tumpang tindih di 03_FAKTOR."),
        ("4. Tarif di atas titik impas",
         "='06_UJI_KELAYAKAN'!$C$28", RP,
         f"='06_UJI_KELAYAKAN'!$C$18*'01_ASUMSI'!{A['phi_toleransi_impas']}", RP, ">=",
         "Tekan biaya operasional, naikkan okupansi, atau tinjau struktur pendanaan."),
        ("5. Tarif di dalam koridor bawah",
         "='06_UJI_KELAYAKAN'!$C$28", RP,
         "='06_UJI_KELAYAKAN'!$C$24", RP, ">=",
         "Tarif terlalu rendah terhadap pasar dan titik impas."),
        ("6. Tarif di dalam koridor atas",
         "='06_UJI_KELAYAKAN'!$C$28", RP,
         "='06_UJI_KELAYAKAN'!$C$25", RP, "<=",
         "Tarif melampaui batas yang dapat dipertahankan."),
        ("7. Koefisien variasi data pembanding",
         f"={CV_CELL}", PCT1,
         f"='01_ASUMSI'!{A['am_cv_pembanding_maks']}", PCT1, "<=",
         "Pembanding terlalu beragam. Buang yang paling menyimpang."),
        ("8. Penyesuaian pembanding terbesar",
         f"={MAX_ADJ}", PCT1,
         f"='01_ASUMSI'!{A['am_penyesuaian_pembanding_maks']}", PCT1, "<=",
         "Ada pembanding yang terlalu berbeda. Ganti dengan yang lebih mirip."),
        ("9. Kelengkapan data unit (sel kosong)",
         f"=SUMPRODUCT(('02_MASTER_UNIT'!$C$5:$C${4+n_unit}=\"\")*1)"
         f"+SUMPRODUCT(('02_MASTER_UNIT'!$D$5:$D${4+n_unit}=\"\")*1)"
         f"+SUMPRODUCT(('02_MASTER_UNIT'!$E$5:$E${4+n_unit}=\"\")*1)", NUM,
         "=0", NUM, "<=",
         "Lengkapi kolom wajib pada 02_MASTER_UNIT."),
    ]
    r_cek_awal = r
    for nama, rumus, fmt, amb, ambfmt, arah, tindakan in cek:
        ws.cell(row=r, column=1, value=nama).font = Font(name=FONT, size=9)
        c1 = ws.cell(row=r, column=2, value=rumus)
        c1.number_format = fmt; c1.font = Font(name=FONT, size=9)
        c2 = ws.cell(row=r, column=3, value=amb)
        c2.number_format = ambfmt; c2.font = Font(name=FONT, size=9, color="595959")
        op = "<=" if arah == "<=" else ">="
        cs = ws.cell(row=r, column=4, value=f'=IF($B{r}{op}$C{r},"LULUS","PERIKSA")')
        cs.font = Font(name=FONT, size=9, bold=True)
        cs.alignment = Alignment(horizontal="center")
        ws.cell(row=r, column=6, value=tindakan).font = Font(
            name=FONT, size=8, italic=True, color="595959")
        r += 1
    r_cek_akhir = r - 1

    r += 1
    label(ws, r, "PEMERIKSAAN TAMBAHAN — Monotonisitas vertikal", bold=True)
    ws.cell(row=r, column=4,
            value=f'=IF(AND($D{r_zona_akhir}>=$D{r_zona_akhir-1},'
                  f'$D{r_zona_akhir-1}>=$D{r_zona_akhir-2}),"LULUS","PERIKSA")'
            ).font = Font(name=FONT, size=9, bold=True)
    ws.cell(row=r, column=6, value="Tarif rata-rata zona atas harus >= zona di bawahnya.").font = Font(
        name=FONT, size=8, italic=True, color="595959")
    r += 1
    label(ws, r, "PEMERIKSAAN TAMBAHAN — Faktor kalibrasi dalam rentang", bold=True)
    ws.cell(row=r, column=4,
            value=f'=IF(AND($B$10>=\'01_ASUMSI\'!{A["am_kalibrasi_k_min"]},'
                  f'$B$10<=\'01_ASUMSI\'!{A["am_kalibrasi_k_maks"]}),"LULUS","PERIKSA")'
            ).font = Font(name=FONT, size=9, bold=True)
    r += 1
    label(ws, r, "PEMERIKSAAN TAMBAHAN — Premi fit-out menutup biaya (Rumus 10.5)", bold=True)
    ws.cell(row=r, column=2,
            value=f"=IFERROR('01_ASUMSI'!{A['fitout_m2']}/($B$7*'01_ASUMSI'!{A['fitout_bulan']}),0)"
            ).number_format = PCT1
    ws.cell(row=r, column=3, value=f"={K_['fully']}").number_format = PCT1
    ws.cell(row=r, column=4, value=f'=IF($C{r}>=$B{r},"LULUS","PERIKSA")').font = Font(
        name=FONT, size=9, bold=True)
    ws.cell(row=r, column=6,
            value="Bila PERIKSA: perpanjang masa sewa, tagih fit-out terpisah, "
                  "atau batasi pada tingkat warm shell.").font = Font(
        name=FONT, size=8, italic=True, color="595959")
    r += 2

    label(ws, r, "JUMLAH PEMERIKSAAN YANG LULUS", bold=True)
    cc = ws.cell(row=r, column=2,
                 value=f'=COUNTIF($D${r_cek_awal}:$D${r_cek_akhir},"LULUS")&" dari 9"')
    cc.font = Font(name=FONT, size=12, bold=True, color="1F3864")
    cc.fill = PatternFill("solid", fgColor=F_KUNCI)
    r += 1
    ws.cell(row=r, column=1,
            value="Seluruh pemeriksaan harus berstatus LULUS sebelum daftar harga diterbitkan. "
                  "Tidak ada pengecualian.").font = Font(
        name=FONT, size=9, italic=True, color="C00000")

    r += 2
    subjudul(ws, f"A{r}", "BAGIAN 4 — STATUS KALIBRASI MODEL", span=6); r += 1
    label(ws, r, "Status kalibrasi faktor lantai")
    isi(ws, r, 2, p["meta"]["status_kalibrasi"], "input", None, kunci=True,
        catatan="Ubah menjadi TERKALIBRASI hanya setelah regresi Bab 12 dijalankan "
                "dengan minimal 30 kontrak di 8 lantai berbeda.", cat_col=6)
    r += 1
    label(ws, r, "Tanggal tinjauan terakhir")
    isi(ws, r, 2, p["meta"]["tanggal"], "input", None)
    r += 1
    label(ws, r, "Tinjauan berikutnya dijadwalkan")
    isi(ws, r, 2, "Kuartal berikutnya", "input", None,
        catatan="Jadwal lengkap pada Bab 20.3 handbook.", cat_col=6)

    normalkan_font(ws)
    ws.freeze_panes = "A4"
    return ws


# ============================================================================
def bangun_baca_saya(wb, p):
    ws = wb.create_sheet("00_BACA_SAYA", 0)
    lebar(ws, {"A": 30, "B": 100})
    judul(ws, "A1", "MODEL PENETAPAN HARGA SEWA GEDUNG MENARA", span=2)
    ws["A2"] = f"{p['gedung']['nama']} — versi {p['meta']['versi']} — {p['meta']['tanggal']}"
    ws["A2"].font = Font(name=FONT, size=11, bold=True)

    isi_teks = [
        ("", ""),
        ("PERINGATAN", "SELURUH ANGKA DALAM BERKAS INI ADALAH DATA KARANGAN (DUMMY). "
                       "Angka disusun agar menyerupai kondisi pasar Jakarta pertengahan 2026, "
                       "tetapi tidak mewakili gedung nyata mana pun. Ganti dengan data Anda sendiri."),
        ("", ""),
        ("LEGENDA WARNA", ""),
        ("Teks BIRU", "Angka yang Anda masukkan sendiri. BOLEH diubah."),
        ("Latar KUNING", "Asumsi kunci yang wajib ditinjau setiap kuartal. BOLEH diubah."),
        ("Teks HITAM", "Hasil rumus di lembar yang sama. JANGAN diubah."),
        ("Teks HIJAU", "Rumus yang mengambil nilai dari lembar lain. JANGAN diubah."),
        ("", ""),
        ("ATURAN TUNGGAL TERPENTING",
         "Bila sebuah sel berwarna HITAM atau HIJAU, jangan diketik ulang. Mengganti rumus dengan "
         "angka adalah cara tercepat merusak model, dan kerusakannya tidak terlihat sampai "
         "berbulan-bulan kemudian."),
        ("", ""),
        ("URUTAN PENGISIAN", ""),
        ("Langkah 1", "Buka 01_ASUMSI. Isi identitas gedung, NLA, dan standar pengukuran."),
        ("Langkah 2", "Buka 05_PEMBANDING. Ganti data pembanding dengan gedung pesaing Anda. "
                      "Minimal 4, idealnya 6–8, seluruhnya berusia di bawah 6 bulan."),
        ("Langkah 3", "Buka 06_UJI_KELAYAKAN. Periksa apakah tarif hasil model masuk akal. "
                      "Isi data keuangan di 01_ASUMSI bila belum."),
        ("Langkah 4", "Buka 02_MASTER_UNIT. Ganti daftar unit dengan data gedung Anda. "
                      "Seluruh kolom bertanda * wajib diisi."),
        ("Langkah 5", "Buka 03_FAKTOR. Setel besaran premi. WAJIB dikalibrasi dengan data setempat "
                      "sebelum dipakai untuk keputusan nyata."),
        ("Langkah 6", "Buka 09_RINGKASAN. Pastikan sembilan pemeriksaan mutu seluruhnya LULUS."),
        ("Langkah 7", "Bila seluruh pemeriksaan lulus, ambil kolom 'R publikasi' pada 04_KALKULASI "
                      "sebagai daftar harga resmi."),
        ("Langkah 8", "Simpan berkas dengan nama bertanggal. JANGAN menimpa versi sebelumnya."),
        ("", ""),
        ("DAFTAR LEMBAR", ""),
        ("01_ASUMSI", "Seluruh parameter model. Hanya lembar ini yang diubah rutin."),
        ("02_MASTER_UNIT", "Daftar unit dan atributnya."),
        ("03_FAKTOR", "Tabel acuan seluruh faktor pengali."),
        ("04_KALKULASI", "Mesin perhitungan tarif per unit. JANGAN DIUBAH."),
        ("05_PEMBANDING", "Grid penyesuaian data pembanding pasar."),
        ("06_UJI_KELAYAKAN", "Pendekatan pendapatan, titik impas, dan pagar pengaman."),
        ("07_NER_INSENTIF", "Sewa efektif bersih dan batas insentif per unit."),
        ("08_SENSITIVITAS", "Tabel sensitivitas, skenario, dan proyeksi lima tahun."),
        ("09_RINGKASAN", "Papan pantau dan sembilan pemeriksaan mutu."),
        ("10_KAMUS_DATA", "Definisi setiap kolom dan satuannya."),
        ("11_SUMBER", "Seluruh rujukan dan tautan sumber."),
        ("", ""),
        ("PEMBATASAN PENGGUNAAN",
         "Berkas ini adalah alat bantu analisis internal, bukan laporan penilaian resmi. Untuk "
         "keperluan yang mengikat secara hukum — jaminan utang, pelaporan keuangan, transaksi, "
         "atau sengketa — hasil model wajib diverifikasi oleh Penilai Publik berizin yang tunduk "
         "pada Standar Penilaian Indonesia."),
    ]
    r = 4
    for kiri, kanan in isi_teks:
        if kiri and not kanan:
            subjudul(ws, f"A{r}", kiri, span=2)
        else:
            c = ws.cell(row=r, column=1, value=kiri)
            c.font = Font(name=FONT, size=10, bold=True)
            c2 = ws.cell(row=r, column=2, value=kanan)
            c2.font = Font(name=FONT, size=10,
                           color="C00000" if kiri in ("PERINGATAN", "ATURAN TUNGGAL TERPENTING") else "000000")
            c2.alignment = Alignment(wrap_text=True, vertical="top")
            if kiri in ("PERINGATAN", "ATURAN TUNGGAL TERPENTING", "PEMBATASAN PENGGUNAAN"):
                ws.row_dimensions[r].height = 42
        r += 1
    normalkan_font(ws)
    return ws


# ============================================================================
def bangun_kamus(wb):
    ws = wb.create_sheet("10_KAMUS_DATA")
    lebar(ws, {"A": 22, "B": 22, "C": 14, "D": 62, "E": 14})
    judul(ws, "A1", "10 — KAMUS DATA", span=5)
    header_baris(ws, 3, ["Lembar", "Nama kolom", "Satuan", "Definisi", "Wajib?"])
    baris = [
        ("02_MASTER_UNIT", "Kode_Gedung", "teks", "Pengenal gedung. Diperlukan bila model diperluas ke banyak gedung.", "Ya"),
        ("02_MASTER_UNIT", "Kode_Unit", "teks", "Pengenal unik unit. Disarankan format KODEGEDUNG-LANTAIHURUF.", "Ya"),
        ("02_MASTER_UNIT", "Lantai", "angka", "Nomor lantai tempat unit berada.", "Ya"),
        ("02_MASTER_UNIT", "Luas_NLA_m2", "m2", "Luas yang ditagihkan, diukur dengan standar yang tercatat di 01_ASUMSI.", "Ya"),
        ("02_MASTER_UNIT", "Kategori_View", "teks", "Salah satu dari: Terhalang, Terbatas, Terbuka, Penanda.", "Ya"),
        ("02_MASTER_UNIT", "Posisi", "teks", "Salah satu dari: Sudut, Hadap_Lift, Dekat_Servis, Ujung_Buntu, Standar.", "Ya"),
        ("02_MASTER_UNIT", "Kondisi_Fitout", "teks", "Salah satu dari: Shell_Core, Warm_Shell, Semi_Fitted, Fully_Fitted.", "Ya"),
        ("02_MASTER_UNIT", "Denah", "teks", "Salah satu dari: Bebas_Kolom, Standar, Banyak_Kolom, Plafon_Tinggi.", "Ya"),
        ("02_MASTER_UNIT", "Status_Hunian", "teks", "Terisi atau Kosong. Dipakai untuk menghitung okupansi aktual.", "Tidak"),
        ("02_MASTER_UNIT", "Nama_Penyewa", "teks", "Nama penyewa saat ini bila unit terisi.", "Tidak"),
        ("04_KALKULASI", "Zona", "teks", "Zona lantai hasil pencarian otomatis dari tabel di 03_FAKTOR.", "Rumus"),
        ("04_KALKULASI", "F lantai DIPAKAI", "faktor", "Faktor lantai yang aktif, mengikuti saklar model di 01_ASUMSI.", "Rumus"),
        ("04_KALKULASI", "F view (dikoreksi)", "faktor", "Faktor pemandangan setelah dikurangi porsi yang sudah terkandung di faktor lantai.", "Rumus"),
        ("04_KALKULASI", "F TOTAL", "faktor", "Hasil perkalian seluruh faktor sebelum pembatasan.", "Rumus"),
        ("04_KALKULASI", "F dibatasi", "faktor", "F TOTAL setelah dibatasi pada rentang aman (Rumus 8.3).", "Rumus"),
        ("04_KALKULASI", "R awal", "Rp/m2/bln", "Tarif unit sebelum kalibrasi (Rumus 8.1).", "Rumus"),
        ("04_KALKULASI", "R final", "Rp/m2/bln", "Tarif unit setelah dikalikan faktor kalibrasi (Rumus 11.2).", "Rumus"),
        ("04_KALKULASI", "R publikasi", "Rp/m2/bln", "Tarif final setelah pembulatan (Rumus 11.3). INI YANG DIPUBLIKASIKAN.", "Rumus"),
        ("04_KALKULASI", "Tarif kotor", "Rp/m2/bln", "R publikasi ditambah service charge. Angka yang dibandingkan calon penyewa.", "Rumus"),
        ("04_KALKULASI", "PPh Final", "Rp/bln", "10% dari tagihan kotor termasuk service charge (PP 34/2017).", "Rumus"),
        ("05_PEMBANDING", "Adj *", "persen", "Penyesuaian per atribut. Negatif bila pembanding lebih baik dari objek.", "Ya"),
        ("05_PEMBANDING", "Total mutlak", "persen", "Jumlah nilai mutlak seluruh penyesuaian. Ambang maksimal 25%.", "Rumus"),
        ("05_PEMBANDING", "Bobot", "persen", "Bobot kemiripan (Rumus 5.2). Pembanding yang lebih mirip diberi bobot lebih besar.", "Rumus"),
        ("07_NER_INSENTIF", "NER", "Rp/m2/bln", "Sewa efektif bersih setelah bulan gratis dan biaya insentif (Rumus 14.1).", "Rumus"),
        ("07_NER_INSENTIF", "Batas bulan gratis", "bulan", "Jumlah maksimum bulan bebas sewa agar NER tetap di atas batas (Rumus 14.4).", "Rumus"),
    ]
    r = 4
    for b_ in baris:
        for i, v in enumerate(b_):
            c = ws.cell(row=r, column=1 + i, value=v)
            c.font = Font(name=FONT, size=9)
            c.border = BORDER
            if i == 3:
                c.alignment = Alignment(wrap_text=True, vertical="top")
        r += 1
    ws.freeze_panes = "A4"
    normalkan_font(ws)
    return ws


def bangun_sumber(wb):
    ws = wb.create_sheet("11_SUMBER")
    lebar(ws, {"A": 8, "B": 52, "C": 30, "D": 78})
    judul(ws, "A1", "11 — SUMBER RUJUKAN DAN TAUTAN", span=4)
    ws["A2"] = ("Setiap angka yang berasal dari luar wajib dicatat sumbernya di sini. "
                "Ini adalah syarat agar model dapat diaudit.")
    ws["A2"].font = Font(name=FONT, size=9, italic=True)

    kel = [
        ("A. STANDAR PENGUKURAN DAN PENILAIAN", [
            ("BOMA International — Office Buildings: Standard Methods of Measurement (ANSI/BOMA Z65.1)",
             "Bab 3 — NLA, faktor beban, Metode A dan B",
             "https://www.boma.org/BOMA/BOMA-Standards/BOMA_Floor_Measurement_Standards/Office_Buildings.aspx"),
            ("BOMA International — daftar seluruh standar",
             "Bab 3 — edisi terbaru tiap jenis properti",
             "https://boma.org/boma-standards/"),
            ("IVSC — IVS 105 Valuation Approaches and Methods",
             "Bab 4 — tiga pendekatan penilaian",
             "https://www.ivsc.org/wp-content/uploads/2021/10/IVS105ValuationApproaches.pdf"),
            ("IVSC — International Valuation Standards",
             "Bab 4 — struktur standar umum dan standar aset",
             "https://ivsc.org/standards/"),
            ("RICS — Valuation Global Standards (Red Book)",
             "Bab 4 — kerangka praktik penilaian global",
             "https://www.rics.org/profession-standards/rics-standards-and-guidance/sector-standards/valuation-standards/red-book/red-book-global"),
            ("MAPPI — KEPI & SPI Edisi VII 2018",
             "Bab 4 dan 6 — SPI 106, metode kapitalisasi langsung",
             "https://ecommerce.mappi.or.id/home/products/kode-etik-penilai-indonesia-dan-standar-penilaian-indonesia-edisi-vii-2018-bundling"),
            ("Penjelasan kedudukan hukum SPI dan PMK 101/2014",
             "Bab 4 — sifat wajib SPI",
             "https://penilaian.id/2022/07/30/apa-itu-standar-penilaian-indonesia-spi/"),
        ]),
        ("B. LITERATUR AKADEMIK", [
            ("Rosen, S. (1974). Hedonic Prices and Implicit Markets. Journal of Political Economy, 82(1), 34–55.",
             "Bab 12 — landasan regresi hedonik",
             "https://doi.org/10.1086/260169"),
            ("Koster, van Ommeren & Rietveld (2014). Is the sky the limit? Journal of Economic Geography, 14(1), 125–153.",
             "Bab 1 dan 9 — premi ~4% per 10 m tinggi gedung",
             "https://doi.org/10.1093/jeg/lbt008"),
            ("Nase, van Assendelft & Remoy (2019). Rent Premiums and Vertical Sorting. JREFE, 59(3), 419–460.",
             "Bab 9 dan 10 — 27% premi vertikal berasal dari pemandangan",
             "https://doi.org/10.1007/s11146-018-9684-x"),
            ("Nutt, O. D. (2016). Uncovering the premium for higher floors in office space. Tesis MIT.",
             "Bab 1 dan 9 — premi lantai positif di 23 dari 25 kota",
             "https://dspace.mit.edu/handle/1721.1/103450"),
            ("Chau, Wong & Yiu (2012). Floor level premium. Journal of Housing and the Built Environment.",
             "Bab 9 — premi lantai mengecil di ketinggian",
             "https://doi.org/10.1007/s10901-010-9203-8"),
            ("Danton & Himbert (2018). Residential vertical rent curves. Journal of Urban Economics, 107, 89–100.",
             "Bab 9 — bentuk kurva sewa vertikal",
             "https://doi.org/10.1016/j.jue.2018.08.002"),
        ]),
        ("C. DATA PASAR (dasar angka dummy)", [
            ("Colliers Indonesia — laporan kuartalan pasar perkantoran Jakarta",
             "Tarif dasar dan service charge",
             "https://www.colliers.com/en-id/research/colliers-quarterly-property-market-report-q1-2026-jakarta-office"),
            ("Ringkasan laporan Colliers Kuartal II 2026",
             "CBD ~Rp218.000; luar CBD ~Rp168.000; Premium ~Rp347.000; Grade A CBD ~Rp234.000; SC CBD ~Rp86.000",
             "https://realestateasia.com/commercial-office/news/jakarta-non-cbd-office-rents-rise-2-3-annually-until-2029"),
            ("Cushman & Wakefield — Jakarta MarketBeat",
             "Base rent CBD ~Rp176.700/m2/bln Q1 2026",
             "https://www.cushmanwakefield.com/en/indonesia/insights/jakarta-marketbeat"),
            ("CBRE Indonesia — Jakarta Office Market Outlook Q1 2026",
             "Proyeksi pertumbuhan sewa 2–3% per tahun; okupansi CBD menuju ~78%",
             "https://indonesia.cbre.com/insights/reports/jakarta-office-market-outlook-q1-2026"),
            ("JLL — Jakarta Office Market Dynamics",
             "Kondisi pasokan dan permintaan",
             "https://www.jll.com/en-sea/insights/market-dynamics/jakarta-office"),
            ("Bank Indonesia — Perkembangan Properti Komersial",
             "Indeks harga dan permintaan properti komersial",
             "https://www.bi.go.id/id/publikasi/laporan/default.aspx?kategori=perkembangan+properti+komersial"),
        ]),
        ("D. PERATURAN PERPAJAKAN", [
            ("Peraturan Pemerintah Nomor 34 Tahun 2017",
             "PPh Final 10%; jumlah bruto termasuk service charge",
             "https://peraturan.bpk.go.id/Download/54909/PP%20Nomor%2034%20Tahun%202017.pdf"),
            ("Salinan PP 34/2017 pada JDIH Kementerian Keuangan",
             "Naskah resmi",
             "https://jdih.kemenkeu.go.id/dok/pp-34-tahun-2017/view"),
            ("DDTCNews — Pajak atas Persewaan Tanah dan/atau Bangunan",
             "Penerapan praktis tarif dan DPP",
             "https://news.ddtc.co.id/literasi/kelas-pajak/39122/pajak-atas-persewaan-tanah-danatau-bangunan"),
            ("Ortax — Pengenaan Pajak Final atas Sewa Tanah dan/atau Bangunan",
             "Cakupan jumlah bruto",
             "https://ortax.org/pajak-penghasilan-atas-persewaan-tanah-dan-atau-bangunan"),
        ]),
    ]
    r = 4
    no = 1
    for nama_kel, isi_kel in kel:
        subjudul(ws, f"A{r}", nama_kel, span=4)
        r += 1
        header_baris(ws, r, ["No", "Rujukan", "Dipakai untuk", "Tautan"])
        r += 1
        for ref, guna, url in isi_kel:
            ws.cell(row=r, column=1, value=no).font = Font(name=FONT, size=9)
            for i, v in enumerate([ref, guna, url]):
                c = ws.cell(row=r, column=2 + i, value=v)
                c.font = Font(name=FONT, size=9,
                              color="0563C1" if i == 2 else "000000")
                c.alignment = Alignment(wrap_text=True, vertical="top")
                c.border = BORDER
            ws.row_dimensions[r].height = 28
            no += 1
            r += 1
        r += 1
    normalkan_font(ws)
    return ws


# ============================================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/parameters.yaml")
    ap.add_argument("--out", default="data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx")
    args = ap.parse_args()

    akar = Path(__file__).resolve().parent.parent
    cfg = akar / args.config
    out = akar / args.out
    out.parent.mkdir(parents=True, exist_ok=True)

    with open(cfg, encoding="utf-8") as fh:
        p = yaml.safe_load(fh)

    wb = Workbook()
    wb.remove(wb.active)

    bangun_asumsi(wb, p)
    unit = data_unit_dummy(p)
    bangun_master_unit(wb, p, unit)
    _, Z, V, P_, K_, D_ = bangun_faktor(wb, p)
    _, r0k, r1k = bangun_kalkulasi(wb, p, len(unit), Z, V, P_, K_, D_)
    _, R_PASAR, CV_CELL, MAX_ADJ, N_COMP = bangun_pembanding(wb, p)
    _, R_MIN, R_IMPAS, R_BUTUH = bangun_kelayakan(wb, p, R_PASAR)
    bangun_ner(wb, p, len(unit), r0k, R_MIN)
    bangun_sensitivitas(wb, p, R_IMPAS)
    bangun_ringkasan(wb, p, len(unit), r0k, r1k, R_PASAR, CV_CELL, MAX_ADJ, N_COMP, Z, K_)
    bangun_kamus(wb)
    bangun_sumber(wb)
    bangun_baca_saya(wb, p)

    urutan = ["00_BACA_SAYA", "01_ASUMSI", "02_MASTER_UNIT", "03_FAKTOR", "04_KALKULASI",
              "05_PEMBANDING", "06_UJI_KELAYAKAN", "07_NER_INSENTIF", "08_SENSITIVITAS",
              "09_RINGKASAN", "10_KAMUS_DATA", "11_SUMBER"]
    wb._sheets = [wb[n] for n in urutan]
    wb.active = 0

    wb.save(out)
    print(f"Berkas dibuat: {out}")
    print(f"Jumlah unit dummy: {len(unit)}")
    print(f"Total NLA dummy: {sum(u['luas'] for u in unit):,.0f} m2")
    print("Langkah berikutnya: jalankan recalc agar seluruh rumus terhitung.")


if __name__ == "__main__":
    main()
