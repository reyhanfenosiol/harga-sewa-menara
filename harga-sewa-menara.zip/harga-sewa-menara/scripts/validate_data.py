#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_data.py
Memeriksa mutu berkas data unit sebelum dimasukkan ke model.

Menjalankan pemeriksaan yang TIDAK dapat dilakukan oleh rumus Excel:
kelengkapan, nilai kategori yang sah, duplikasi, dan kewajaran angka.

Pemakaian:
    python3 scripts/validate_data.py data/template/master_unit.csv
    python3 scripts/validate_data.py --xlsx data/dummy/Model_Harga_Sewa_Menara_DUMMY.xlsx

Kode keluar: 0 bila lolos, 1 bila ada galat.
"""

import argparse
import sys
from pathlib import Path

import pandas as pd
import yaml

KOLOM_WAJIB = ["Kode_Gedung", "Kode_Unit", "Lantai", "Luas_NLA_m2",
               "Kategori_View", "Posisi", "Kondisi_Fitout", "Denah"]

HIJAU, MERAH, KUNING, RESET = "\033[92m", "\033[91m", "\033[93m", "\033[0m"


class Hasil:
    def __init__(self):
        self.galat = []
        self.peringatan = []

    def g(self, pesan):
        self.galat.append(pesan)

    def p(self, pesan):
        self.peringatan.append(pesan)

    def laporkan(self):
        print()
        if not self.galat and not self.peringatan:
            print(f"{HIJAU}LOLOS — tidak ada galat maupun peringatan.{RESET}")
            return 0
        for x in self.galat:
            print(f"{MERAH}GALAT     {RESET} {x}")
        for x in self.peringatan:
            print(f"{KUNING}PERINGATAN{RESET} {x}")
        print()
        print(f"Ringkasan: {len(self.galat)} galat, {len(self.peringatan)} peringatan.")
        if self.galat:
            print(f"{MERAH}Perbaiki seluruh GALAT sebelum menjalankan model.{RESET}")
            return 1
        print(f"{HIJAU}Tidak ada galat. Peringatan sebaiknya ditinjau.{RESET}")
        return 0


def muat_kategori_sah(akar):
    cfg = akar / "config" / "parameters.yaml"
    with open(cfg, encoding="utf-8") as fh:
        p = yaml.safe_load(fh)
    return {
        "Kategori_View": set(p["faktor_view"]["kategori"].keys()),
        "Posisi": set(p["faktor_posisi"].keys()),
        "Kondisi_Fitout": set(k for k in p["faktor_kondisi"].keys()
                              if k not in ("biaya_fitout_rp_m2", "masa_sewa_acuan_bulan")),
        "Denah": set(p["faktor_denah"].keys()),
    }, p


def periksa(df, sah, p, h):
    # 1. Kolom wajib ada
    hilang = [k for k in KOLOM_WAJIB if k not in df.columns]
    if hilang:
        h.g(f"Kolom wajib tidak ditemukan: {', '.join(hilang)}")
        return

    # 2. Sel kosong pada kolom wajib
    for k in KOLOM_WAJIB:
        n = int(df[k].isna().sum())
        if n:
            baris = [i + 2 for i in df.index[df[k].isna()].tolist()[:8]]
            h.g(f"Kolom '{k}' memiliki {n} sel kosong (baris berkas: {baris}).")

    # 3. Kode unit ganda
    ganda = df["Kode_Unit"][df["Kode_Unit"].duplicated(keep=False)].unique().tolist()
    if len(ganda):
        h.g(f"Kode_Unit ganda ditemukan: {ganda[:10]}")

    # 4. Nilai kategori yang tidak dikenal
    for kol, nilai_sah in sah.items():
        if kol not in df.columns:
            continue
        asing = sorted(set(df[kol].dropna().astype(str)) - nilai_sah)
        if asing:
            h.g(f"Kolom '{kol}' memuat nilai yang tidak ada di 03_FAKTOR: {asing}. "
                f"Nilai yang sah: {sorted(nilai_sah)}")

    # 5. Kewajaran angka
    lantai = pd.to_numeric(df["Lantai"], errors="coerce")
    luas = pd.to_numeric(df["Luas_NLA_m2"], errors="coerce")
    if lantai.isna().any():
        h.g("Kolom 'Lantai' memuat nilai yang bukan angka.")
    if luas.isna().any():
        h.g("Kolom 'Luas_NLA_m2' memuat nilai yang bukan angka.")

    if not lantai.isna().all():
        maks = p["gedung"]["jumlah_lantai"]
        minl = p["gedung"]["lantai_sewa_mulai"]
        luar = df.loc[(lantai < minl) | (lantai > maks), "Kode_Unit"].tolist()
        if luar:
            h.g(f"Unit berada di luar rentang lantai {minl}–{maks}: {luar[:10]}")

    if not luas.isna().all():
        if (luas <= 0).any():
            h.g("Terdapat unit dengan luas nol atau negatif.")
        kecil = df.loc[luas < 20, "Kode_Unit"].tolist()
        if kecil:
            h.p(f"Unit dengan luas di bawah 20 m2 — periksa satuannya: {kecil[:10]}")
        besar = df.loc[luas > 5000, "Kode_Unit"].tolist()
        if besar:
            h.p(f"Unit dengan luas di atas 5.000 m2 — periksa satuannya: {besar[:10]}")

        total = float(luas.sum())
        nla_cfg = p["gedung"]["nla_m2"]
        selisih = abs(total - nla_cfg) / nla_cfg if nla_cfg else 1
        if selisih > 0.005:
            h.g(f"Total luas unit {total:,.0f} m2 tidak sama dengan NLA di parameters.yaml "
                f"({nla_cfg:,.0f} m2). Selisih {selisih:.2%}.")
        else:
            print(f"  Total luas unit {total:,.0f} m2 cocok dengan NLA konfigurasi.")

    # 6. Sebaran lantai — syarat kalibrasi regresi (Bab 12)
    n_lantai = int(lantai.dropna().nunique())
    if n_lantai < 8:
        h.p(f"Hanya {n_lantai} lantai berbeda. Kalibrasi regresi Bab 12 membutuhkan "
            f"minimal 8 lantai; gunakan tabel zona konservatif.")

    # 7. Jumlah unit
    if len(df) < 10:
        h.p(f"Hanya {len(df)} unit. Model tetap berjalan, tetapi kalibrasi menjadi kurang andal.")

    print(f"  Jumlah unit      : {len(df)}")
    print(f"  Lantai berbeda   : {n_lantai}")
    if "Status_Hunian" in df.columns and not luas.isna().all():
        terisi = luas[df["Status_Hunian"].astype(str).str.strip().str.lower() == "terisi"].sum()
        print(f"  Okupansi (luas)  : {terisi / luas.sum():.1%}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("berkas", nargs="?", help="Berkas CSV berisi data unit")
    ap.add_argument("--xlsx", help="Baca lembar 02_MASTER_UNIT dari berkas Excel")
    args = ap.parse_args()

    akar = Path(__file__).resolve().parent.parent
    sah, p = muat_kategori_sah(akar)
    h = Hasil()

    if args.xlsx:
        jalur = Path(args.xlsx)
        if not jalur.is_absolute():
            jalur = akar / jalur
        df = pd.read_excel(jalur, sheet_name="02_MASTER_UNIT", header=3)
        df.columns = [str(c).replace(" *", "").strip() for c in df.columns]
        df = df[df["Kode_Unit"].notna()]
        df = df[df["Kode_Unit"].astype(str).str.strip() != ""]
        sumber = f"{jalur.name} (lembar 02_MASTER_UNIT)"
    elif args.berkas:
        jalur = Path(args.berkas)
        if not jalur.is_absolute():
            jalur = akar / jalur
        if not jalur.exists():
            print(f"{MERAH}Berkas tidak ditemukan: {jalur}{RESET}")
            return 1
        df = pd.read_csv(jalur)
        df.columns = [str(c).replace(" *", "").strip() for c in df.columns]
        sumber = jalur.name
    else:
        ap.print_help()
        return 1

    print(f"Memeriksa: {sumber}")
    periksa(df, sah, p, h)
    return h.laporkan()


if __name__ == "__main__":
    sys.exit(main())
