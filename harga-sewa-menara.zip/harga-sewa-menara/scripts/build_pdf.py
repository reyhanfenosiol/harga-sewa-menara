#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_pdf.py
Mengubah handbook Markdown menjadi PDF.

Mesin utama : XeLaTeX melalui pandoc (rumus matematika ter-render penuh).
Mesin cadangan: wkhtmltopdf melalui HTML, bila XeLaTeX tidak tersedia.

Pemakaian:
    python3 scripts/build_pdf.py
    python3 scripts/build_pdf.py --engine html
"""

import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

PREAMBLE = r"""
\usepackage{etoolbox}
\usepackage{longtable,booktabs,array}
\usepackage{ragged2e}

% Tabel lebar dibuat lebih rapat dan berukuran kecil agar tidak meluber
\AtBeginEnvironment{longtable}{\footnotesize}
\setlength{\tabcolsep}{3.5pt}
\renewcommand{\arraystretch}{1.15}

% Judul bab diberi jarak yang lega
\usepackage{titlesec}
\titleformat{\section}{\LARGE\bfseries\color{birutua}}{\thesection}{0pt}{}
\titleformat{\subsection}{\Large\bfseries\color{birutua}}{\thesubsection}{0pt}{}
\titlespacing*{\section}{0pt}{22pt}{10pt}
\titlespacing*{\subsection}{0pt}{16pt}{8pt}

\usepackage{xcolor}
\definecolor{birutua}{HTML}{1F3864}
\definecolor{abu}{HTML}{595959}

% Kutipan blok dipakai untuk blok sumber
\usepackage{mdframed}
\newmdenv[
  linewidth=0pt,
  backgroundcolor=black!4,
  innerleftmargin=8pt, innerrightmargin=8pt,
  innertopmargin=6pt, innerbottommargin=6pt,
  skipabove=8pt, skipbelow=8pt
]{blokkutip}
\renewenvironment{quote}{\begin{blokkutip}\small\color{abu}}{\end{blokkutip}}

\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\scriptsize\color{abu} Handbook Penentuan Harga Sewa Gedung Menara}
\fancyhead[R]{\scriptsize\color{abu} v1.0}
\fancyfoot[C]{\small\thepage}
\renewcommand{\headrulewidth}{0.4pt}

\usepackage{microtype}
\hyphenpenalty=1500
"""


def punya(prog):
    return shutil.which(prog) is not None


def bangun_latex(md, pdf, template=None):
    with tempfile.NamedTemporaryFile("w", suffix=".tex", delete=False,
                                     encoding="utf-8") as fh:
        fh.write(PREAMBLE)
        pre = fh.name

    perintah = [
        "pandoc", str(md), "-o", str(pdf),
        "--pdf-engine=xelatex",
        "--toc", "--toc-depth=2",
        "-V", "documentclass=report",
        "-V", "geometry:a4paper,margin=2.2cm,includehead",
        "-V", "fontsize=10pt",
        "-V", "mainfont=TeX Gyre Pagella",
        "-V", "sansfont=Carlito",
        "-V", "monofont=Latin Modern Mono",
        "-V", "linkcolor=blue",
        "-V", "urlcolor=blue",
        "-V", "toccolor=black",
        "-V", "colorlinks=true",
        "-H", pre,
        "--wrap=preserve",
    ]
    if template and Path(template).exists():
        perintah += ["--template", str(template)]
    hasil = subprocess.run(perintah, capture_output=True, text=True)
    Path(pre).unlink(missing_ok=True)
    return hasil


def bangun_html(md, pdf, css):
    html = pdf.with_suffix(".html")
    p1 = subprocess.run(
        ["pandoc", str(md), "-o", str(html), "--standalone",
         "--toc", "--toc-depth=2", "--mathml",
         "--metadata", "title=Handbook Penentuan Harga Sewa Gedung Menara"]
        + (["--css", str(css)] if css.exists() else []),
        capture_output=True, text=True)
    if p1.returncode != 0:
        return p1
    return subprocess.run(
        ["wkhtmltopdf", "--enable-local-file-access",
         "--margin-top", "18mm", "--margin-bottom", "18mm",
         "--margin-left", "16mm", "--margin-right", "16mm",
         "--footer-center", "[page]", "--footer-font-size", "8",
         str(html), str(pdf)],
        capture_output=True, text=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--md", default="docs/HANDBOOK-HARGA-SEWA-MENARA.md")
    ap.add_argument("--out", default="docs/HANDBOOK-HARGA-SEWA-MENARA.pdf")
    ap.add_argument("--engine", choices=["latex", "html"], default="latex")
    args = ap.parse_args()

    akar = Path(__file__).resolve().parent.parent
    md = akar / args.md
    pdf = akar / args.out
    css = akar / "assets" / "style" / "handbook.css"

    if not md.exists():
        print(f"Berkas Markdown tidak ditemukan: {md}")
        return 1
    if not punya("pandoc"):
        print("pandoc tidak terpasang. Pasang lebih dulu: apt-get install pandoc")
        return 1

    mesin = args.engine
    if mesin == "latex" and not punya("xelatex"):
        print("XeLaTeX tidak ditemukan — beralih ke mesin HTML.")
        mesin = "html"

    print(f"Membangun PDF dengan mesin: {mesin}")
    tmpl = akar / "assets" / "style" / "handbook-template.tex"
    hasil = bangun_latex(md, pdf, tmpl) if mesin == "latex" else bangun_html(md, pdf, css)

    if hasil.returncode != 0:
        print("Gagal membangun PDF.")
        print((hasil.stderr or hasil.stdout)[-3000:])
        if mesin == "latex":
            print("\nMencoba mesin cadangan HTML...")
            hasil = bangun_html(md, pdf, css)
            if hasil.returncode != 0:
                print((hasil.stderr or hasil.stdout)[-2000:])
                return 1
        else:
            return 1

    if pdf.exists():
        print(f"PDF dibuat: {pdf}  ({pdf.stat().st_size/1024:.0f} KB)")
        return 0
    print("PDF tidak terbentuk.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
