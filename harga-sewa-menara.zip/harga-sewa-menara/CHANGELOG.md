# Riwayat Perubahan

Format: setiap perubahan asumsi wajib dicatat beserta alasan dan tanggalnya.
Ini adalah syarat agar model dapat diaudit di kemudian hari.

---

## [1.0] — 2026-08-23

### Rilis awal

**Handbook**
- 22 bab, 5 bagian, 2 lampiran, 43 halaman.
- 40+ rumus bernomor, seluruhnya disertai penjelasan sederhana, contoh angka, dan sumber.
- Rujukan standar: ANSI/BOMA Z65.1, IVS 105, RICS Red Book, KEPI & SPI Edisi VII 2018.
- Rujukan akademik: Rosen (1974), Koster dkk. (2014), Nase dkk. (2019), Nutt (2016),
  Chau dkk. (2012), Danton & Himbert (2018), Liu dkk. (2018), Wheaton & Torto (1988).
- Rujukan perpajakan: PP 34/2017.

**Model Excel**
- 12 lembar kerja, 2.674 rumus, 64 unit dummy, NLA 33.600 m2.
- Model faktor multiplikatif dengan dua pilihan faktor lantai: zona dan logaritmik.
- Kalibrasi otomatis ke jangkar pasar (Rumus 11.1).
- Koreksi tumpang tindih pemandangan dengan faktor lantai, porsi 27%
  berdasarkan Nase dkk. (2019).
- Sembilan pemeriksaan mutu tertanam, ditambah tiga pemeriksaan tambahan.
- Verifikasi: recalc LibreOffice melaporkan 0 galat dari 2.674 rumus.

**Asumsi awal (data dummy)**
| Parameter | Nilai | Dasar |
|---|---|---|
| Tarif dasar | mengikuti hasil model | Rumus 7.3 |
| Service charge | Rp 62.000/m2/bln | Acuan pasar desentralisasi Jakarta, Colliers Q2 2026 |
| Tarif pembanding premium | Rp 234.000/m2/bln | Acuan Grade A CBD, Colliers Q2 2026 |
| Okupansi target | 78% | Proyeksi CBRE untuk CBD Jakarta |
| Eskalasi sewa | 3,0%/tahun | Proyeksi Colliers dan CBRE 2%–3% per tahun |
| Eskalasi service charge | 3,0%/tahun | Proyeksi Colliers sampai 2029 |
| PPh Final sewa | 10% | PP 34/2017 |
| PPN | 11% | Perlu diverifikasi ulang saat digunakan |
| Status kalibrasi | BELUM_TERKALIBRASI | Faktor lantai memakai nilai konservatif |

### Perubahan selama penyusunan

- **2026-08-23** — Nilai aset diturunkan dari Rp 1,15 triliun menjadi Rp 700 miliar dan
  cap rate target dari 8,25% menjadi 7,00%.
  *Alasan:* pada asumsi semula, tarif yang dibutuhkan mencapai Rp 377.617/m2/bln, sekitar
  dua kali lipat indikasi pasar. Kesenjangan sebesar itu membuat seluruh model berstatus
  merah dan tidak lagi berguna sebagai contoh pembelajaran. Nilai baru menghasilkan
  kesenjangan 24% yang tetap mencerminkan kondisi nyata pasar perkantoran Jakarta.

- **2026-08-23** — Cicilan utang tahunan diturunkan dari Rp 38 miliar menjadi Rp 22 miliar.
  *Alasan:* pada angka semula, tarif titik impas Rp 215.011/m2/bln berada di atas indikasi
  pasar, sehingga pagar pengaman selalu mengikat dan tarif dasar terdorong di atas pasar.
  Angka baru menghasilkan titik impas Rp 163.139/m2/bln dan okupansi impas 69%.

- **2026-08-23** — Insentif baku diubah: bulan bebas sewa dari 3 menjadi 2, biaya perbaikan
  ruang dari Rp 450.000/m2 menjadi Rp 250.000/m2.
  *Alasan:* pada angka semula seluruh 64 unit berstatus di bawah batas NER, sehingga lembar
  07 tidak memberi informasi apa pun. Angka baru menghasilkan 43 unit aman dan 21 unit perlu
  diperiksa, yang mencerminkan situasi negosiasi sebenarnya.

### Perbaikan galat

- Rujukan kolom dari `04_KALKULASI` ke `02_MASTER_UNIT` bergeser satu kolom, sehingga
  faktor pemandangan, posisi, kondisi, dan denah seluruhnya bernilai netral dan okupansi
  aktual terbaca 0%. Diperbaiki dan diverifikasi ulang secara silang per unit.
- Rumus teks pada `07_NER_INSENTIF` memiliki tanda kurung berlebih yang menimbulkan `#VALUE!`.
- Alamat sel premi fit-out pada pemeriksaan mutu dibuat dinamis, tidak lagi ditulis tetap.

---

## Cara Menambah Catatan Baru

```
## [versi] — YYYY-MM-DD

### Perubahan asumsi
- **Parameter:** nilai lama -> nilai baru
  *Alasan:* ...
  *Sumber:* ...
  *Dampak pada tarif dasar:* ...
```
